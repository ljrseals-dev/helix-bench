import { create } from "zustand";
import {
  DEMO_SR,
  analyzeAlignment,
  buildDemo,
  deEss,
  delaySignal,
  detectBreaths,
  dtw,
  dtwCausal,
  dynamicsCurve,
  f0At,
  featuresOf,
  formantLockedShift,
  mapFromNodes,
  mixLayers,
  naivePitchShift,
  nodesFromPath,
  pathErrorMs,
  protectTransients,
  psolaRender,
  renderSpans,
  segmentNotes,
  spectralFluxTimes,
  trackF0,
  envelopeErrorDb,
  type BreathSpan,
  type F0Frame,
  type NoteEvent,
  type QcReport,
  type QcWeights,
  type Span,
  type WarpNode,
  type WarpPoint,
} from "@/lib/dsp/engine";
import { decodeMono, toWorkingRate } from "@/lib/studio/playback";

export type ToolId = "qc" | "bridge" | "formant" | "nudge" | "align" | "stack" | "vox" | "stream";

export interface HarmonyLayer {
  id: string;
  name: string;
  semitones: number;
  loose: Float32Array;
  f0: F0Frame[];
  map: (t: number) => number;
  mute: boolean;
  solo: boolean;
  nudgeMs: number;
  align: boolean;
}

export interface StreamReport {
  lookaheadMs: number;
  pathErrorMs: number;
  microsPerFrame: number;
  ringBytes: number;
  events: { t: number; refT: number; lagMs: number }[];
}

interface StudioState {
  booting: boolean;
  status: string;
  tool: ToolId;
  sampleRate: number;
  duration: number;
  reference: Float32Array | null;
  processed: Float32Array | null;
  refF0: F0Frame[];
  procF0: F0Frame[];
  refSpans: Span[];
  editSpans: Span[];
  undo: Span[][];
  trackerMae: number;
  weights: QcWeights;
  qc: QcReport | null;
  lastRender: Float32Array | null;
  lastLabel: string;
  pitch: number;
  formant: number;
  preserve: boolean;
  deess: boolean;
  wet: number;
  formantSource: "reference" | "processed";
  formantPreview: Float32Array | null;
  bench: { locked: number; naive: number; lockedF0: number; naiveF0: number } | null;
  radius: number;
  correction: number;
  lockConsonants: boolean;
  nodes: WarpNode[];
  layers: HarmonyLayer[];
  tightness: number;
  leadInMix: boolean;
  mix: Float32Array | null;
  scaleNote: string;
  notes: NoteEvent[];
  breaths: BreathSpan[];
  dynamics: { t: number; value: number }[];
  stream: StreamReport | null;
  boot: () => Promise<void>;
  setTool: (tool: ToolId) => void;
  setWeights: (weights: QcWeights) => void;
  recomputeQc: () => void;
  importClip: (role: "reference" | "processed", file: File) => Promise<void>;
  resetDemo: () => Promise<void>;
  setPitch: (pitch: number) => void;
  setFormant: (formant: number) => void;
  setPreserve: (preserve: boolean) => void;
  setDeess: (deess: boolean) => void;
  setWet: (wet: number) => void;
  setFormantSource: (source: "reference" | "processed") => void;
  renderFormant: () => void;
  runBench: () => void;
  setRadius: (radius: number) => void;
  setCorrection: (correction: number) => void;
  setLockConsonants: (lock: boolean) => void;
  traceWarp: () => void;
  moveNode: (index: number, ref: number, src: number) => void;
  renderAlign: () => void;
  setSpans: (spans: Span[], remember?: boolean) => void;
  undoSpan: () => void;
  snapSpans: () => void;
  renderNudge: () => void;
  ensureStack: () => void;
  setTightness: (tightness: number) => void;
  patchLayer: (id: string, patch: Partial<Pick<HarmonyLayer, "mute" | "solo" | "nudgeMs" | "align">>) => void;
  setLeadInMix: (lead: boolean) => void;
  renderStack: () => void;
  runScale: () => void;
  refreshVox: () => void;
  runStream: (lookaheadMs: number) => void;
}

let bootPromise: Promise<void> | null = null;
const DEFAULT_WEIGHTS: QcWeights = { f0: 0.4, time: 0.3, mcd: 0.15, boundary: 0.15 };

function onsets(spans: Span[]): number[] {
  return spans.filter((span) => span.kind !== "gap").map((span) => span.t0);
}

function qcOf(
  reference: Float32Array,
  processed: Float32Array,
  refF0: F0Frame[],
  procF0: F0Frame[],
  refSpans: Span[],
  procSpans: Span[],
  weights: QcWeights,
): QcReport {
  return analyzeAlignment({
    reference,
    processed,
    sampleRate: DEMO_SR,
    refF0,
    procF0,
    refOnsets: onsets(refSpans),
    procOnsets: onsets(procSpans),
    weights,
  });
}

function owned(samples: Float32Array): Float32Array {
  return samples instanceof Float32Array && samples.byteOffset === 0 && samples.buffer.byteLength === samples.byteLength
    ? samples
    : samples.slice();
}

export const useStudio = create<StudioState>((set, get) => ({
  booting: true,
  status: "Scoring the house take",
  tool: "qc",
  sampleRate: DEMO_SR,
  duration: 0,
  reference: null,
  processed: null,
  refF0: [],
  procF0: [],
  refSpans: [],
  editSpans: [],
  undo: [],
  trackerMae: 0,
  weights: DEFAULT_WEIGHTS,
  qc: null,
  lastRender: null,
  lastLabel: "",
  pitch: 7,
  formant: 0,
  preserve: true,
  deess: true,
  wet: 1,
  formantSource: "reference",
  formantPreview: null,
  bench: null,
  radius: 40,
  correction: 80,
  lockConsonants: true,
  nodes: [],
  layers: [],
  tightness: 70,
  leadInMix: true,
  mix: null,
  scaleNote: "",
  notes: [],
  breaths: [],
  dynamics: [],
  stream: null,

  boot: () => {
    if (bootPromise) return bootPromise;
    bootPromise = get()
      .resetDemo()
      .catch((error: unknown) => {
        bootPromise = null;
        set({ booting: false, status: error instanceof Error ? error.message : "The house take failed to score." });
      });
    return bootPromise;
  },

  setTool: (tool) => {
    set({ tool });
    if (tool === "stack") get().ensureStack();
    if (tool === "vox") get().refreshVox();
    if (tool === "stream" && !get().stream) get().runStream(120);
  },

  setWeights: (weights) => {
    set({ weights });
    get().recomputeQc();
  },

  recomputeQc: () => {
    const s = get();
    if (!s.reference || !s.processed) return;
    const target = s.lastRender ?? s.processed;
    const targetF0 = s.lastRender ? trackF0(s.lastRender, DEMO_SR) : s.procF0;
    const spans = s.lastRender ? s.refSpans : s.editSpans;
    set({
      qc: qcOf(s.reference, target, s.refF0, targetF0, s.refSpans, spans, s.weights),
      status: s.lastRender ? "Scores are against the latest render" : "Scores are against the unaligned take",
    });
  },

  importClip: async (role, file) => {
    set({ status: `Reading ${file.name}` });
    try {
      const decoded = await decodeMono(file);
      const samples = owned(toWorkingRate(decoded.samples, decoded.sampleRate, DEMO_SR));
      const f0 = trackF0(samples, DEMO_SR);
      const patch =
        role === "reference"
          ? { reference: samples, refF0: f0, refSpans: [] as Span[] }
          : { processed: samples, procF0: f0, editSpans: [] as Span[] };
      set({
        ...patch,
        duration: Math.max(get().reference?.length ?? 0, samples.length) / DEMO_SR,
        lastRender: null,
        formantPreview: null,
        layers: [],
        mix: null,
        bench: null,
        booting: false,
      });
      const next = get();
      if (next.reference && next.processed) {
        set({
          duration: Math.max(next.reference.length, next.processed.length) / DEMO_SR,
          qc: qcOf(next.reference, next.processed, next.refF0, next.procF0, next.refSpans, next.editSpans, next.weights),
          status: `${file.name} is in the session at 22.05 kHz`,
        });
        get().traceWarp();
      }
    } catch (error) {
      set({ status: error instanceof Error ? error.message : "That file could not be decoded." });
    }
  },

  resetDemo: async () => {
    set({ booting: true, status: "Scoring the house take", lastRender: null, formantPreview: null, layers: [], mix: null, bench: null });
    await new Promise((resolve) => setTimeout(resolve, 20));
    const demo = buildDemo();
    const qc = qcOf(demo.reference, demo.processed, demo.refF0, demo.procF0, demo.refSpans, demo.procSpans, get().weights);
    const n = Math.min(featuresOf(demo.processed, DEMO_SR).length, featuresOf(demo.reference, DEMO_SR).length);
    const srcFeat = featuresOf(demo.processed, DEMO_SR).slice(0, n);
    const refFeat = featuresOf(demo.reference, DEMO_SR).slice(0, n);
    const nodes = nodesFromPath(dtw(srcFeat, refFeat, get().radius).path);
    set({
      booting: false,
      status: `Tracker vs score ${demo.trackerMaeCents.toFixed(1)} cents`,
      sampleRate: DEMO_SR,
      duration: demo.duration,
      reference: demo.reference,
      processed: demo.processed,
      refF0: demo.refF0,
      procF0: demo.procF0,
      refSpans: demo.refSpans,
      editSpans: demo.procSpans.map((span) => ({ ...span })),
      undo: [],
      trackerMae: demo.trackerMaeCents,
      qc,
      nodes,
      notes: [],
      breaths: [],
      stream: null,
      scaleNote: "",
    });
  },

  setPitch: (pitch) => set({ pitch }),
  setFormant: (formant) => set({ formant }),
  setPreserve: (preserve) => set({ preserve }),
  setDeess: (deess) => set({ deess }),
  setWet: (wet) => set({ wet }),
  setFormantSource: (formantSource) => set({ formantSource, formantPreview: null, bench: null }),

  renderFormant: () => {
    const s = get();
    const source = s.formantSource === "reference" ? s.reference : s.processed;
    if (!source) return;
    set({ status: "Shifting" });
    const shifted = s.preserve ? formantLockedShift(source, DEMO_SR, s.pitch, s.formant) : naivePitchShift(source, s.pitch);
    const wet = s.deess ? deEss(shifted, DEMO_SR) : shifted;
    const mixed = new Float32Array(source.length);
    const gain = s.wet;
    for (let i = 0; i < mixed.length; i++) mixed[i] = source[i] * (1 - gain) + (wet[i] ?? 0) * gain;
    set({ formantPreview: mixed, lastRender: mixed, lastLabel: "formant", status: s.preserve ? "Envelope locked" : "Naive resample" });
  },

  runBench: () => {
    const s = get();
    const source = s.formantSource === "reference" ? s.reference : s.processed;
    if (!source) return;
    set({ status: "Measuring +7 semitones" });
    const locked = formantLockedShift(source, DEMO_SR, 7, 0);
    const naive = naivePitchShift(source, 7);
    const lockedF0 = medianVoiced(trackF0(locked, DEMO_SR));
    const naiveF0 = medianVoiced(trackF0(naive, DEMO_SR));
    set({
      bench: {
        locked: envelopeErrorDb(source, locked, DEMO_SR),
        naive: envelopeErrorDb(source, naive, DEMO_SR),
        lockedF0,
        naiveF0,
      },
      formantPreview: locked,
      lastRender: locked,
      lastLabel: "bench-locked",
      status: "Bench is the locked take",
    });
  },

  setRadius: (radius) => set({ radius }),
  setCorrection: (correction) => set({ correction }),
  setLockConsonants: (lockConsonants) => set({ lockConsonants }),

  traceWarp: () => {
    const s = get();
    if (!s.reference || !s.processed) return;
    const srcFeat = featuresOf(s.processed, DEMO_SR);
    const refFeat = featuresOf(s.reference, DEMO_SR);
    const n = Math.min(srcFeat.length, refFeat.length);
    let nodes = nodesFromPath(dtw(srcFeat.slice(0, n), refFeat.slice(0, n), s.radius).path);
    if (s.lockConsonants) nodes = protectTransients(nodes, spectralFluxTimes(s.processed, DEMO_SR));
    set({ nodes, status: `${nodes.length} warp nodes` });
  },

  moveNode: (index, ref, src) => {
    const nodes = get().nodes.map((node) => ({ ...node }));
    if (!nodes[index]) return;
    const prev = nodes[index - 1];
    const next = nodes[index + 1];
    const duration = get().duration || 1;
    nodes[index].ref = Math.min(next ? next.ref - 0.01 : duration, Math.max(prev ? prev.ref + 0.01 : 0, ref));
    nodes[index].src = Math.min(next ? next.src - 0.01 : duration, Math.max(prev ? prev.src + 0.01 : 0, src));
    set({ nodes });
  },

  renderAlign: () => {
    const s = get();
    if (!s.reference || !s.processed || s.nodes.length < 2) return;
    set({ status: "Warping the take onto the reference" });
    const map = mapFromNodes(s.nodes);
    const amount = s.correction / 100;
    const rendered = psolaRender({
      input: s.processed,
      sampleRate: DEMO_SR,
      f0: s.procF0,
      outLength: s.reference.length,
      mapIn: (sample) => Math.max(0, Math.min(s.processed!.length - 2, map(sample / DEMO_SR) * DEMO_SR)),
      pitchRatioAtIn: (inSample) => {
        const srcF = f0At(s.procF0, inSample / DEMO_SR);
        const refF = f0At(s.refF0, mapInverseGuess(s.nodes, inSample / DEMO_SR));
        if (srcF <= 0 || refF <= 0) return 1;
        return (refF / srcF) ** amount;
      },
    });
    const qc = qcOf(s.reference, rendered, s.refF0, trackF0(rendered, DEMO_SR), s.refSpans, s.refSpans, s.weights);
    set({ lastRender: rendered, lastLabel: "aligned", qc, status: `Aligned score ${qc.score.toFixed(0)}` });
  },

  setSpans: (spans, remember = true) => {
    const undo = remember ? [...get().undo, get().editSpans.map((span) => ({ ...span }))].slice(-40) : get().undo;
    set({ editSpans: spans, undo });
  },
  undoSpan: () => {
    const undo = get().undo.slice();
    const prev = undo.pop();
    if (prev) set({ editSpans: prev, undo });
  },
  snapSpans: () => {
    const s = get();
    if (!s.refSpans.length || !s.editSpans.length) return;
    const next = s.editSpans.map((span, index) => {
      const ref = s.refSpans[index];
      return ref ? { ...span, t0: ref.t0, t1: ref.t1 } : span;
    });
    get().setSpans(next);
    set({ status: "Boundaries snapped to the reference score" });
  },
  renderNudge: () => {
    const s = get();
    if (!s.processed || !s.editSpans.length) return;
    set({ status: "Stretching phonemes" });
    const rendered = renderSpans(s.processed, DEMO_SR, s.editSpans, s.procF0);
    set({ lastRender: rendered, lastLabel: "nudged", status: "Phoneme render is ready" });
  },

  ensureStack: () => {
    const s = get();
    if (s.layers.length || !s.reference) return;
    set({ status: "Stacking four harmonies" });
    const intervals = [3, 7, 10, 12];
    const refFeat = featuresOf(s.reference, DEMO_SR);
    const layers: HarmonyLayer[] = intervals.map((semitones, index) => {
      const shifted = formantLockedShift(s.reference!, DEMO_SR, semitones, 0);
      const delaySec = 0.018 + index * 0.011;
      const wobble = 0.006 + index * 0.002;
      const loose = delaySignal(shifted, DEMO_SR, delaySec, wobble);
      const feat = featuresOf(loose, DEMO_SR);
      const n = Math.min(feat.length, refFeat.length);
      const map = mapFromNodes(nodesFromPath(dtw(feat.slice(0, n), refFeat.slice(0, n), 36).path));
      return {
        id: `h${semitones}`,
        name: semitones > 0 ? `+${semitones}` : `${semitones}`,
        semitones,
        loose,
        f0: trackF0(loose, DEMO_SR),
        map,
        mute: false,
        solo: false,
        nudgeMs: 0,
        align: true,
      };
    });
    set({ layers, status: "Harmonies are drifted on purpose" });
    get().renderStack();
  },

  setTightness: (tightness) => set({ tightness }),
  patchLayer: (id, patch) => {
    set({ layers: get().layers.map((layer) => (layer.id === id ? { ...layer, ...patch } : layer)) });
  },
  setLeadInMix: (leadInMix) => set({ leadInMix }),

  renderStack: () => {
    const s = get();
    if (!s.layers.length || !s.reference) return;
    const solo = s.layers.some((layer) => layer.solo);
    const amount = s.tightness / 100;
    const voices = s.layers
      .filter((layer) => !layer.mute && (!solo || layer.solo))
      .map((layer) => renderHarmony(layer, amount));
    if (s.leadInMix) voices.unshift(s.reference);
    set({ mix: voices.length ? mixLayers(voices, 0.8) : null, status: `Mix at ${s.tightness}% tightness` });
  },

  runScale: () => {
    const s = get();
    if (!s.reference) return;
    const feat = featuresOf(s.reference, DEMO_SR);
    const t0 = performance.now();
    for (let i = 0; i < 24; i++) {
      const jitter = feat.map((row) => {
        const copy = row.slice();
        copy[0] += i * 0.01;
        return copy;
      });
      dtw(jitter, feat, 24);
    }
    const ms = performance.now() - t0;
    set({ scaleNote: `24 layers · ${ms.toFixed(0)} ms DTW · ${(ms / 24).toFixed(1)} ms each · features only, sources untouched` });
  },

  refreshVox: () => {
    const s = get();
    const frames = s.refF0.length ? s.refF0 : s.procF0;
    const audio = s.reference ?? s.processed;
    if (!audio || !frames.length) return;
    set({
      notes: segmentNotes(frames),
      breaths: detectBreaths(audio, DEMO_SR, frames),
      dynamics: dynamicsCurve(frames),
    });
  },

  runStream: (lookaheadMs) => {
    const s = get();
    if (!s.reference || !s.processed) return;
    const ref = featuresOf(s.reference, DEMO_SR);
    const src = featuresOf(s.processed, DEMO_SR);
    const n = Math.min(ref.length, src.length);
    const offline = dtw(src.slice(0, n), ref.slice(0, n), s.radius).path;
    const frames = Math.max(1, Math.round(lookaheadMs / 10));
    const causal = dtwCausal(src.slice(0, n), ref.slice(0, n), s.radius, frames);
    const events = causal.path.filter((_, index) => index % 12 === 0).map((point: WarpPoint) => ({
      t: point.i * 0.01,
      refT: point.j * 0.01,
      lagMs: (point.i - point.j) * 10,
    }));
    set({
      stream: {
        lookaheadMs,
        pathErrorMs: pathErrorMs(causal.path, offline),
        microsPerFrame: causal.microsPerFrame,
        ringBytes: Math.round(lookaheadMs * 0.001 * DEMO_SR * 4),
        events,
      },
    });
  },
}));

function medianVoiced(frames: F0Frame[]): number {
  const vals = frames.filter((frame) => frame.f0 > 0).map((frame) => frame.f0);
  if (!vals.length) return 0;
  vals.sort((a, b) => a - b);
  return vals[vals.length >> 1];
}

function requireEnvelope(): { envelopeErrorDb: typeof import("@/lib/dsp/engine").envelopeErrorDb } {
  return { envelopeErrorDb: envelopeErrorDbLazy };
}

import { envelopeErrorDb as envelopeErrorDbLazy } from "@/lib/dsp/engine";
import { renderSpans as renderSpansLazy } from "@/lib/dsp/engine";

function loadRenderSpans(): { renderSpans: typeof renderSpansLazy } {
  return { renderSpans: renderSpansLazy };
}

function mapInverseGuess(nodes: WarpNode[], srcTime: number): number {
  if (nodes.length < 2) return srcTime;
  let best = nodes[0];
  let bestD = Infinity;
  for (const node of nodes) {
    const d = Math.abs(node.src - srcTime);
    if (d < bestD) {
      bestD = d;
      best = node;
    }
  }
  return best.ref;
}

function renderHarmony(layer: HarmonyLayer, amount: number): Float32Array {
  const nudged = delaySignal(layer.loose, DEMO_SR, layer.nudgeMs / 1000, 0);
  if (!layer.align || amount < 0.02) return nudged;
  return psolaRender({
    input: nudged,
    sampleRate: DEMO_SR,
    f0: layer.f0,
    outLength: nudged.length,
    mapIn: (sample) => {
      const t = sample / DEMO_SR;
      const blended = t * (1 - amount) + layer.map(t) * amount;
      return Math.max(0, Math.min(nudged.length - 2, blended * DEMO_SR));
    },
    pitchRatioAtIn: () => 1,
  });
}
