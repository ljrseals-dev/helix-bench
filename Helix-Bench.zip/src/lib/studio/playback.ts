import { resampleLinear } from "@/lib/dsp/signal";

let ctx: AudioContext | null = null;
let node: AudioBufferSourceNode | null = null;

function context(): AudioContext {
  if (!ctx) ctx = new AudioContext();
  return ctx;
}

export function stopAudio(): void {
  if (!node) return;
  try {
    node.onended = null;
    node.stop();
  } catch {
    /* already stopped */
  }
  node.disconnect();
  node = null;
}

export function playSamples(samples: Float32Array, sampleRate: number, onEnded?: () => void): void {
  if (typeof window === "undefined" || samples.length < 2) return;
  const audio = context();
  void audio.resume();
  stopAudio();
  const buffer = audio.createBuffer(1, samples.length, sampleRate);
  buffer.getChannelData(0).set(samples);
  const source = audio.createBufferSource();
  source.buffer = buffer;
  source.connect(audio.destination);
  source.onended = () => {
    if (node === source) node = null;
    onEnded?.();
  };
  source.start();
  node = source;
}

export async function decodeMono(file: File): Promise<{ samples: Float32Array; sampleRate: number }> {
  const audio = context();
  void audio.resume();
  const encoded = await file.arrayBuffer();
  const decoded = await audio.decodeAudioData(encoded.slice(0));
  const mono = new Float32Array(decoded.length);
  const channels = decoded.numberOfChannels;
  for (let c = 0; c < channels; c++) {
    const data = decoded.getChannelData(c);
    for (let i = 0; i < mono.length; i++) mono[i] += data[i] / channels;
  }
  const capped = mono.length > decoded.sampleRate * 90 ? mono.slice(0, Math.floor(decoded.sampleRate * 90)) : mono;
  return { samples: capped, sampleRate: decoded.sampleRate };
}

export function toWorkingRate(samples: Float32Array, sampleRate: number, targetRate: number): Float32Array {
  if (sampleRate === targetRate) return samples;
  return resampleLinear(samples, sampleRate, targetRate);
}

export function downloadBlob(filename: string, blob: Blob): void {
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

export function downloadText(filename: string, text: string, type = "text/plain"): void {
  downloadBlob(filename, new Blob([text], { type }));
}
