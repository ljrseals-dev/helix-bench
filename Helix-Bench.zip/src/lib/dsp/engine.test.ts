import assert from "node:assert/strict";
import test from "node:test";
import {
  analyzeAlignment,
  buildDemo,
  dtw,
  dtwCausal,
  encodeMidi,
  envelopeErrorDb,
  featuresOf,
  formantLockedShift,
  mapPhonemes,
  naivePitchShift,
  pathErrorMs,
  synthesizeScore,
  trackF0,
  type ScoreEvent,
} from "./engine.ts";

function sine(freq: number, sr: number, dur: number): Float32Array {
  const n = Math.floor(sr * dur);
  const y = new Float32Array(n);
  for (let i = 0; i < n; i++) y[i] = 0.6 * Math.sin((2 * Math.PI * freq * i) / sr);
  return y;
}

test("YIN locks a 220 Hz sine", () => {
  const sr = 22050;
  const y = sine(220, sr, 1.2);
  const frames = trackF0(y, sr).filter((frame) => frame.f0 > 0);
  assert.ok(frames.length > 20);
  const mid = frames[Math.floor(frames.length / 2)].f0;
  assert.ok(Math.abs(mid - 220) < 3, `got ${mid}`);
});

test("DTW stays on the diagonal for identical features", () => {
  const frames: Float64Array[] = [];
  let s = 3;
  for (let i = 0; i < 60; i++) {
    s = (s * 17 + 5) % 97;
    const row = new Float64Array(4);
    for (let k = 0; k < 4; k++) row[k] = ((s + k * 13) % 50) / 10;
    frames.push(row);
  }
  const { path } = dtw(frames, frames, 8);
  const mean = path.reduce((acc, p) => acc + Math.abs(p.i - p.j), 0) / path.length;
  assert.ok(mean < 1.2, `mean diagonal error ${mean}`);
});

test("known cent offset is recovered", () => {
  const sr = 22050;
  const base = sine(196, sr, 1.4);
  const sharp = sine(196 * 2 ** (1 / 12), sr, 1.4);
  const report = analyzeAlignment({
    reference: base,
    processed: sharp,
    sampleRate: sr,
    weights: { f0: 1, time: 1, mcd: 1, boundary: 1 },
  });
  assert.ok(Math.abs(report.f0MaeCents - 100) < 15, `mae ${report.f0MaeCents}`);
});

test("phoneme map flags a lateral fricative and suggests a substitute for glottal stop", () => {
  const items = mapPhonemes("ipa", "synthv-en", "p ɬ ʔ");
  assert.equal(items[0]?.status, "exact");
  assert.equal(items[0]?.target, "p");
  assert.equal(items[1]?.status, "unmappable");
  assert.ok((items[1]?.confidence ?? 1) < 0.5);
  assert.equal(items[2]?.status, "substituted");
  assert.ok((items[2]?.confidence ?? 1) < 0.95);
  assert.notEqual(items[2]?.target, "—");
});

test("MIDI starts with a standard header", () => {
  const bytes = encodeMidi([
    { start: 0, end: 0.5, midi: 60, confidence: 1, bend: [{ t: 0.1, cents: 20 }], vibrato: null },
  ]);
  assert.equal(String.fromCharCode(...bytes.slice(0, 4)), "MThd");
});

test("formant-locked shift keeps the envelope better than naive resample", () => {
  const score: ScoreEvent[] = [
    {
      symbol: "OW",
      ipa: "oʊ",
      t0: 0.05,
      t1: 1.15,
      voiced: true,
      midi: 60,
      f1: 480,
      f2: 860,
      f3: 2400,
      kind: "vowel",
    },
  ];
  const sr = 22050;
  const vowel = synthesizeScore(score, sr, 1.25);
  const locked = formantLockedShift(vowel, sr, 7, 0);
  const naive = naivePitchShift(vowel, 7);
  const lockedErr = envelopeErrorDb(vowel, locked, sr);
  const naiveErr = envelopeErrorDb(vowel, naive, sr);
  assert.ok(lockedErr < naiveErr, `locked ${lockedErr.toFixed(2)} vs naive ${naiveErr.toFixed(2)}`);
  const frames = trackF0(locked, sr).filter((frame) => frame.f0 > 0);
  const mid = frames[Math.floor(frames.length / 2)]?.f0 ?? 0;
  const target = 440 * 2 ** ((60 - 69) / 12) * 2 ** (7 / 12);
  assert.ok(Math.abs(1200 * Math.log2(mid / target)) < 80, `f0 ${mid} target ${target}`);
});

test("smaller streaming lookahead is less faithful than a wide one", () => {
  const demo = buildDemo();
  const ref = featuresOf(demo.reference, demo.sampleRate);
  const src = featuresOf(demo.processed, demo.sampleRate);
  const n = Math.min(ref.length, src.length);
  const offline = dtw(src.slice(0, n), ref.slice(0, n), 48).path;
  const tight = dtwCausal(src.slice(0, n), ref.slice(0, n), 48, 4).path;
  const wide = dtwCausal(src.slice(0, n), ref.slice(0, n), 48, 40).path;
  const tightErr = pathErrorMs(tight, offline);
  const wideErr = pathErrorMs(wide, offline);
  assert.ok(wideErr <= tightErr + 2, `wide ${wideErr.toFixed(1)} tight ${tightErr.toFixed(1)}`);
});

test("demo tracker agrees with the score", () => {
  const demo = buildDemo();
  assert.ok(demo.trackerMaeCents < 45, `tracker mae ${demo.trackerMaeCents}`);
  assert.ok(demo.reference.length > 1000);
  assert.equal(demo.refSpans.filter((span) => span.symbol === "OW").length, 2);
});
