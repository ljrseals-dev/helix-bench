/** Shared numeric helpers: interpolation, FFT, resampling, WAV/MIDI/PDF packing. */

export function interp(samples: Float32Array, x: number): number {
  const n = samples.length;
  if (n === 0) return 0;
  if (x <= 0) return samples[0];
  if (x >= n - 1) return samples[n - 1];
  const i = Math.floor(x);
  const f = x - i;
  const y0 = samples[i - 1] ?? samples[i];
  const y1 = samples[i];
  const y2 = samples[i + 1];
  const y3 = samples[i + 2] ?? y2;
  const a = -0.5 * y0 + 1.5 * y1 - 1.5 * y2 + 0.5 * y3;
  const b = y0 - 2.5 * y1 + 2 * y2 - 0.5 * y3;
  const c = -0.5 * y0 + 0.5 * y2;
  return ((a * f + b) * f + c) * f + y1;
}

export function resampleLinear(input: Float32Array, fromSr: number, toSr: number): Float32Array {
  if (fromSr === toSr) return input.slice();
  const outLen = Math.max(1, Math.round((input.length * toSr) / fromSr));
  const out = new Float32Array(outLen);
  const step = fromSr / toSr;
  for (let i = 0; i < outLen; i++) {
    const x = i * step;
    const i0 = Math.floor(x);
    const frac = x - i0;
    const a = input[Math.min(input.length - 1, Math.max(0, i0))];
    const b = input[Math.min(input.length - 1, i0 + 1)] ?? a;
    out[i] = a + (b - a) * frac;
  }
  return out;
}

export function lowpassCascade(samples: Float32Array, sampleRate: number, cutoff: number, poles = 3): Float32Array {
  let src = samples;
  const dt = 1 / sampleRate;
  const alpha = dt / (1 / (2 * Math.PI * cutoff) + dt);
  for (let pole = 0; pole < poles; pole++) {
    const y = new Float32Array(src.length);
    let prev = 0;
    for (let i = 0; i < src.length; i++) {
      prev += alpha * (src[i] - prev);
      y[i] = prev;
    }
    src = y;
  }
  return src;
}

export function peakNormalize(samples: Float32Array, peak = 0.89): Float32Array {
  let max = 1e-8;
  for (let i = 0; i < samples.length; i++) {
    const s = samples[i];
    if (Number.isFinite(s)) max = Math.max(max, Math.abs(s));
  }
  const gain = peak / max;
  const out = new Float32Array(samples.length);
  for (let i = 0; i < samples.length; i++) out[i] = Number.isFinite(samples[i]) ? samples[i] * gain : 0;
  return out;
}

export function rmsRange(samples: Float32Array, start: number, len: number): number {
  let sum = 0;
  const end = Math.min(samples.length, start + len);
  const n = Math.max(1, end - Math.max(0, start));
  for (let i = Math.max(0, start); i < end; i++) sum += samples[i] * samples[i];
  return Math.sqrt(sum / n);
}

export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Radix-2 complex FFT. Inverse scales by 1/n. Length must be a power of two. */
export function fft(re: Float64Array, im: Float64Array, inverse = false): void {
  const n = re.length;
  for (let i = 1, j = 0; i < n; i++) {
    let bit = n >> 1;
    for (; j & bit; bit >>= 1) j ^= bit;
    j ^= bit;
    if (i < j) {
      const tr = re[i];
      re[i] = re[j];
      re[j] = tr;
      const ti = im[i];
      im[i] = im[j];
      im[j] = ti;
    }
  }
  const sign = inverse ? 1 : -1;
  for (let len = 2; len <= n; len <<= 1) {
    const ang = (sign * 2 * Math.PI) / len;
    const wlenRe = Math.cos(ang);
    const wlenIm = Math.sin(ang);
    for (let i = 0; i < n; i += len) {
      let wRe = 1;
      let wIm = 0;
      const half = len >> 1;
      for (let k = 0; k < half; k++) {
        const aRe = re[i + k];
        const aIm = im[i + k];
        const bRe = re[i + k + half] * wRe - im[i + k + half] * wIm;
        const bIm = re[i + k + half] * wIm + im[i + k + half] * wRe;
        re[i + k] = aRe + bRe;
        im[i + k] = aIm + bIm;
        re[i + k + half] = aRe - bRe;
        im[i + k + half] = aIm - bIm;
        const nextRe = wRe * wlenRe - wIm * wlenIm;
        wIm = wRe * wlenIm + wIm * wlenRe;
        wRe = nextRe;
      }
    }
  }
  if (inverse) {
    for (let i = 0; i < n; i++) {
      re[i] /= n;
      im[i] /= n;
    }
  }
}

export function shiftSamples(samples: Float32Array, sampleRate: number, ms: number): Float32Array {
  const out = new Float32Array(samples.length);
  const shift = Math.round((ms / 1000) * sampleRate);
  for (let i = 0; i < samples.length; i++) {
    const j = i - shift;
    if (j >= 0 && j < samples.length) out[i] = samples[j];
  }
  return out;
}

export function encodeWav(samples: Float32Array, sampleRate: number): Blob {
  const buffer = new ArrayBuffer(44 + samples.length * 2);
  const view = new DataView(buffer);
  const write = (offset: number, text: string) => {
    for (let i = 0; i < text.length; i++) view.setUint8(offset + i, text.charCodeAt(i));
  };
  write(0, "RIFF");
  view.setUint32(4, 36 + samples.length * 2, true);
  write(8, "WAVE");
  write(12, "fmt ");
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true);
  view.setUint16(22, 1, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * 2, true);
  view.setUint16(32, 2, true);
  view.setUint16(34, 16, true);
  write(36, "data");
  view.setUint32(40, samples.length * 2, true);
  let offset = 44;
  for (let i = 0; i < samples.length; i++) {
    const s = Math.max(-1, Math.min(1, Number.isFinite(samples[i]) ? samples[i] : 0));
    view.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7fff, true);
    offset += 2;
  }
  return new Blob([buffer], { type: "audio/wav" });
}

export function simplePdf(title: string, lines: string[]): Uint8Array {
  const escape = (s: string) => s.replace(/\\/g, "\\\\").replace(/\(/g, "\\(").replace(/\)/g, "\\)");
  const body = [`BT /F1 16 Tf 48 780 Td (${escape(title)}) Tj`, `/F1 10 Tf`];
  for (const line of lines.slice(0, 42)) body.push(`0 -16 Td (${escape(line).slice(0, 110)}) Tj`);
  body.push("ET");
  const stream = body.join("\n");
  const objects = [
    `1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj\n`,
    `2 0 obj << /Type /Pages /Count 1 /Kids [3 0 R] >> endobj\n`,
    `3 0 obj << /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >> endobj\n`,
    `4 0 obj << /Length ${stream.length} >> stream\n${stream}\nendstream endobj\n`,
    `5 0 obj << /Type /Font /Subtype /Type1 /BaseFont /Helvetica >> endobj\n`,
  ];
  let pdf = "%PDF-1.4\n";
  const offsets = [0];
  for (const obj of objects) {
    offsets.push(pdf.length);
    pdf += obj;
  }
  const xref = pdf.length;
  pdf += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`;
  for (let i = 1; i < offsets.length; i++) pdf += `${String(offsets[i]).padStart(10, "0")} 00000 n \n`;
  pdf += `trailer << /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`;
  return new TextEncoder().encode(pdf);
}
