/** PSOLA / WSOLA renders, house-score synthesis, note extraction, MIDI. */

import {
  f0At,
  spectralFlatnessFrame,
  trackF0,
  type F0Frame,
} from "./analyze.ts";
import { fft, interp, mulberry32, peakNormalize } from "./signal.ts";

export function psolaRender(opts: {
  input: Float32Array;
  sampleRate: number;
  f0: F0Frame[];
  outLength: number;
  mapIn: (outSample: number) => number;
  pitchRatioAtIn: (inSample: number) => number;
}): Float32Array {
  const { input, sampleRate, f0 } = opts;
  const outLength = Math.max(1, opts.outLength | 0);
  const out = new Float32Array(outLength);
  const norm = new Float32Array(outLength);
  const marks = buildMarks(input.length, sampleRate, f0);
  let outPos = 0;
  let guard = 0;
  while (outPos < outLength - 2 && guard++ < outLength) {
    const mapped = opts.mapIn(outPos);
    const inPos = Number.isFinite(mapped) ? Math.max(0, Math.min(input.length - 2, mapped)) : 0;
    const rawF = f0At(f0, inPos / sampleRate);
    const freq = Number.isFinite(rawF) ? rawF : 0;
    const voiced = freq > 55 && freq < 1100;
    const analysisPeriod = voiced ? sampleRate / freq : sampleRate * 0.01;
    let ratio = 1;
    if (voiced) {
      const requested = opts.pitchRatioAtIn(inPos);
      ratio = Number.isFinite(requested) ? Math.min(2.6, Math.max(0.5, requested)) : 1;
    }
    const targetPeriod = Math.min(sampleRate * 0.025, Math.max(16, analysisPeriod / ratio));
    const mark = nearestMark(marks, inPos);
    const grainLen = Math.round(Math.min(sampleRate * 0.05, Math.max(48, analysisPeriod * 2, targetPeriod * 2)));
    const half = grainLen >> 1;
    const base = Math.round(outPos);
    for (let k = -half; k < grainLen - half; k++) {
      const ip = mark + k;
      const op = base + k;
      if (ip < 0 || op < 0 || ip >= input.length || op >= outLength) continue;
      const w = 0.5 - 0.5 * Math.cos((2 * Math.PI * (k + half)) / grainLen);
      out[op] += input[ip] * w;
      norm[op] += w;
    }
    outPos += targetPeriod;
  }
  for (let i = 0; i < outLength; i++) {
    if (norm[i] > 1e-4) out[i] /= norm[i];
  }
  const fade = Math.min(Math.round(sampleRate * 0.008), Math.floor(outLength / 4));
  for (let i = 0; i < fade; i++) {
    const g = i / Math.max(1, fade);
    out[i] *= g;
    out[outLength - 1 - i] *= g;
  }
  return out;
}

function buildMarks(length: number, sampleRate: number, f0: F0Frame[]): number[] {
  const marks: number[] = [];
  let cursor = 0;
  let guard = 0;
  while (cursor < length - 8 && guard++ < length) {
    const freq = f0At(f0, cursor / sampleRate);
    const period = freq > 55 && freq < 1100 ? sampleRate / freq : sampleRate * 0.01;
    const step = Math.max(16, Math.round(Math.min(sampleRate * 0.02, period)));
    const next = marks.length === 0 ? step : marks[marks.length - 1] + step;
    if (next >= length - 1) break;
    marks.push(next);
    cursor = next;
  }
  return marks;
}

function nearestMark(marks: number[], pos: number): number {
  if (!marks.length) return Math.max(0, Math.round(pos));
  let lo = 0;
  let hi = marks.length - 1;
  while (lo < hi) {
    const mid = (lo + hi) >> 1;
    if (marks[mid] < pos) lo = mid + 1;
    else hi = mid;
  }
  const a = marks[Math.max(0, lo - 1)];
  const b = marks[lo];
  return Math.abs(a - pos) <= Math.abs(b - pos) ? a : b;
}

export function wsolaToLength(input: Float32Array, outLength: number): Float32Array {
  if (input.length < 128 || outLength < 128) {
    const out = new Float32Array(Math.max(1, outLength));
    const step = (input.length - 1) / Math.max(1, out.length - 1);
    for (let i = 0; i < out.length; i++) out[i] = interp(input, i * step);
    return out;
  }
  const win = 256;
  const synHop = 128;
  const anaHop = synHop / Math.max(0.25, outLength / input.length);
  const out = new Float32Array(outLength);
  const norm = new Float32Array(outLength);
  let ana = 0;
  let syn = 0;
  let guard = 0;
  while (syn + win < outLength && ana + win < input.length && guard++ < outLength) {
    for (let i = 0; i < win; i++) {
      const w = 0.5 - 0.5 * Math.cos((2 * Math.PI * i) / (win - 1));
      out[syn + i] += input[ana + i] * w;
      norm[syn + i] += w;
    }
    const nextSyn = syn + synHop;
    const ideal = ana + anaHop;
    let best = Math.round(ideal);
    let bestScore = -1e18;
    const from = Math.max(0, Math.round(ideal - 40));
    const to = Math.min(input.length - win - 1, Math.round(ideal + 40));
    for (let pos = from; pos <= to; pos += 2) {
      let c = 0;
      let e = 1e-8;
      for (let i = 0; i < win - synHop; i += 2) {
        const o = nextSyn + i;
        if (o >= outLength || norm[o] < 1e-5) continue;
        const cand = input[pos + i];
        c += (out[o] / norm[o]) * cand;
        e += cand * cand;
      }
      const score = c / Math.sqrt(e);
      if (score > bestScore) {
        bestScore = score;
        best = pos;
      }
    }
    ana = Math.max(0, Math.min(input.length - win - 1, best));
    syn = nextSyn;
  }
  for (let i = 0; i < outLength; i++) {
    if (norm[i] > 1e-4) out[i] /= norm[i];
    else out[i] = interp(input, (i / Math.max(1, outLength - 1)) * (input.length - 1));
  }
  return out;
}

export function naivePitchShift(input: Float32Array, semitones: number): Float32Array {
  const ratio = 2 ** (semitones / 12);
  const shortLen = Math.max(32, Math.round(input.length / ratio));
  const short = new Float32Array(shortLen);
  for (let i = 0; i < shortLen; i++) short[i] = interp(input, i * ratio);
  return wsolaToLength(short, input.length);
}

function sampleSeries(values: Float64Array, x: number): number {
  if (x <= 0) return values[0];
  const last = values.length - 1;
  if (x >= last) return values[last];
  const i = Math.floor(x);
  const f = x - i;
  return values[i] * (1 - f) + values[i + 1] * f;
}

/** Constant-ratio pitch shift that pins the cepstral envelope (formants) unless asked to move it. */
export function spectralPitchShift(
  input: Float32Array,
  sampleRate: number,
  semitones: number,
  formantSemitones = 0,
): Float32Array {
  const nfft = 1024;
  const hop = 256;
  const pitchR = 2 ** (semitones / 12);
  const formantR = 2 ** (formantSemitones / 12);
  const out = new Float32Array(input.length);
  const norm = new Float32Array(input.length);
  const phase = new Float64Array(nfft / 2 + 1);
  const lifter = 30;
  for (let start = 0; start + nfft <= input.length; start += hop) {
    const re = new Float64Array(nfft);
    const im = new Float64Array(nfft);
    for (let i = 0; i < nfft; i++) {
      const w = 0.5 - 0.5 * Math.cos((2 * Math.PI * i) / (nfft - 1));
      re[i] = input[start + i] * w;
    }
    fft(re, im, false);
    const mag = new Float64Array(nfft / 2 + 1);
    for (let k = 0; k < mag.length; k++) mag[k] = Math.hypot(re[k], im[k]) + 1e-10;
    const logMag = new Float64Array(nfft);
    for (let k = 0; k < mag.length; k++) {
      const v = Math.log(mag[k]);
      logMag[k] = v;
      if (k > 0 && k < nfft / 2) logMag[nfft - k] = v;
    }
    const cim = new Float64Array(nfft);
    fft(logMag, cim, true);
    for (let i = lifter; i <= nfft - lifter; i++) {
      logMag[i] = 0;
      cim[i] = 0;
    }
    fft(logMag, cim, false);
    const env = new Float64Array(mag.length);
    for (let k = 0; k < env.length; k++) env[k] = Math.exp(logMag[k]);
    const nre = new Float64Array(nfft);
    const nim = new Float64Array(nfft);
    for (let k = 0; k < mag.length; k++) {
      const src = k / pitchR;
      const residual = sampleSeries(mag, src) / Math.max(1e-8, sampleSeries(env, src));
      const shaped = residual * sampleSeries(env, k / formantR);
      phase[k] += (2 * Math.PI * hop * k) / nfft;
      const c = Math.cos(phase[k]);
      const s = Math.sin(phase[k]);
      nre[k] = shaped * c;
      nim[k] = shaped * s;
      if (k > 0 && k < nfft / 2) {
        nre[nfft - k] = nre[k];
        nim[nfft - k] = -nim[k];
      }
    }
    fft(nre, nim, true);
    for (let i = 0; i < nfft; i++) {
      const w = 0.5 - 0.5 * Math.cos((2 * Math.PI * i) / (nfft - 1));
      const o = start + i;
      if (o >= out.length) break;
      out[o] += nre[i] * w;
      norm[o] += w * w;
    }
  }
  for (let i = 0; i < out.length; i++) if (norm[i] > 1e-6) out[i] /= norm[i];
  return peakNormalize(out, 0.85);
}

export function formantLockedShift(
  input: Float32Array,
  _sampleRate: number,
  semitones: number,
  formantSemitones = 0,
): Float32Array {
  return spectralPitchShift(input, _sampleRate, semitones, formantSemitones);
}

export function deEss(samples: Float32Array, sampleRate: number): Float32Array {
  const out = samples.slice();
  const hop = Math.max(1, Math.round(sampleRate * 0.01));
  const hp = new Float32Array(samples.length);
  const alpha = Math.exp((-2 * Math.PI * 5500) / sampleRate);
  let prev = 0;
  for (let i = 0; i < samples.length; i++) {
    const low = samples[i] + alpha * (prev - samples[i]);
    hp[i] = samples[i] - low;
    prev = low;
  }
  for (let start = 0; start < samples.length; start += hop) {
    let full = 0;
    let high = 0;
    const end = Math.min(samples.length, start + hop);
    for (let i = start; i < end; i++) {
      full += samples[i] * samples[i];
      high += hp[i] * hp[i];
    }
    const ratio = high / (full + 1e-8);
    if (ratio > 0.28) {
      const g = Math.max(0.35, 1 - (ratio - 0.28) * 1.8);
      for (let i = start; i < end; i++) out[i] = samples[i] - hp[i] * (1 - g);
    }
  }
  return out;
}

export function delaySignal(samples: Float32Array, sampleRate: number, delaySec: number, wobbleAmp = 0): Float32Array {
  const out = new Float32Array(samples.length);
  for (let i = 0; i < samples.length; i++) {
    const t = i / sampleRate;
    const delay = delaySec + wobbleAmp * Math.sin(2 * Math.PI * 0.35 * t);
    out[i] = interp(samples, i - delay * sampleRate);
  }
  return out;
}

export function mixLayers(layers: Float32Array[], gain = 0.7): Float32Array {
  const n = layers.reduce((m, layer) => Math.max(m, layer.length), 0);
  const out = new Float32Array(n);
  for (const layer of layers) {
    for (let i = 0; i < layer.length; i++) out[i] += layer[i];
  }
  return peakNormalize(out, gain);
}

export interface NoteEvent {
  start: number;
  end: number;
  midi: number;
  confidence: number;
  bend: { t: number; cents: number }[];
  vibrato: { rateHz: number; depthCents: number } | null;
}

export interface BreathSpan {
  start: number;
  end: number;
  confidence: number;
}

export function midiOf(freq: number): number {
  return 69 + 12 * Math.log2(freq / 440);
}

export function segmentNotes(frames: F0Frame[]): NoteEvent[] {
  const notes: NoteEvent[] = [];
  let current: { start: number; midi: number; cents: number[]; times: number[]; conf: number[] } | null = null;
  const flush = (endTime: number) => {
    if (!current || endTime - current.start < 0.08 || current.cents.length < 3) {
      current = null;
      return;
    }
    let mean = 0;
    for (const c of current.cents) mean += c;
    mean /= current.cents.length;
    const residual = current.cents.map((c) => c - mean);
    let crossings = 0;
    for (let i = 1; i < residual.length; i++) {
      if ((residual[i - 1] <= 0 && residual[i] > 0) || (residual[i - 1] >= 0 && residual[i] < 0)) crossings++;
    }
    const dt =
      current.times.length > 1
        ? (current.times[current.times.length - 1] - current.times[0]) / (current.times.length - 1)
        : 0.01;
    const rate = dt > 0 ? crossings / 2 / (residual.length * dt) : 0;
    let rss = 0;
    for (const c of residual) rss += c * c;
    const depth = Math.sqrt(rss / residual.length) * Math.SQRT2;
    const vibrato = rate >= 3.5 && rate <= 8.5 && depth >= 18 ? { rateHz: rate, depthCents: depth } : null;
    notes.push({
      start: current.start,
      end: endTime,
      midi: current.midi,
      confidence: current.conf.reduce((s, v) => s + v, 0) / current.conf.length,
      bend: current.times
        .map((t, idx) => ({ t, cents: Math.max(-200, Math.min(200, current!.cents[idx] - mean)) }))
        .filter((_, idx) => idx % 2 === 0),
      vibrato,
    });
    current = null;
  };
  for (const frame of frames) {
    if (frame.f0 <= 0) {
      if (current) flush(frame.time);
      continue;
    }
    const midi = Math.round(midiOf(frame.f0));
    const cents = (midiOf(frame.f0) - midi) * 100;
    if (!current) {
      current = { start: frame.time, midi, cents: [cents], times: [frame.time], conf: [frame.confidence] };
      continue;
    }
    if (Math.abs(midiOf(frame.f0) - current.midi) > 0.7) {
      flush(frame.time);
      current = { start: frame.time, midi, cents: [cents], times: [frame.time], conf: [frame.confidence] };
    } else {
      current.cents.push((midiOf(frame.f0) - current.midi) * 100);
      current.times.push(frame.time);
      current.conf.push(frame.confidence);
    }
  }
  if (current && frames.length) flush(frames[frames.length - 1].time + 0.01);
  return notes;
}

export function detectBreaths(samples: Float32Array, sampleRate: number, frames: F0Frame[]): BreathSpan[] {
  const spans: BreathSpan[] = [];
  let run: { t0: number; flat: number; n: number } | null = null;
  for (const frame of frames) {
    const sample = Math.round(frame.time * sampleRate);
    const flat = spectralFlatnessFrame(samples, Math.max(0, sample - 256), 512);
    const breathy = frame.f0 <= 0 && frame.energy > 0.008 && flat > 0.32;
    if (breathy) {
      if (!run) run = { t0: frame.time, flat: 0, n: 0 };
      run.flat += flat;
      run.n++;
    } else if (run) {
      if (frame.time - run.t0 > 0.05) spans.push({ start: run.t0, end: frame.time, confidence: Math.min(1, run.flat / run.n) });
      run = null;
    }
  }
  return spans;
}

export function dynamicsCurve(frames: F0Frame[]): { t: number; value: number }[] {
  let peak = 1e-6;
  for (const frame of frames) peak = Math.max(peak, frame.energy);
  return frames.map((frame) => ({ t: frame.time, value: Math.min(1, frame.energy / peak) }));
}

function vlq(value: number): number[] {
  let v = Math.max(0, value | 0);
  const bytes = [v & 0x7f];
  v >>= 7;
  while (v > 0) {
    bytes.unshift((v & 0x7f) | 0x80);
    v >>= 7;
  }
  return bytes;
}

export function encodeMidi(notes: NoteEvent[], bpm = 96): Uint8Array {
  const tpq = 480;
  const secToTick = (s: number) => Math.max(0, Math.round((s * bpm * tpq) / 60));
  const uspq = Math.round(60000000 / bpm);
  const events: { tick: number; data: number[] }[] = [
    { tick: 0, data: [0xff, 0x51, 0x03, (uspq >> 16) & 0xff, (uspq >> 8) & 0xff, uspq & 0xff] },
    { tick: 0, data: [0xc0, 54] },
  ];
  for (const note of notes) {
    const pitch = Math.max(0, Math.min(127, note.midi));
    events.push({ tick: secToTick(note.start), data: [0x90, pitch, 86] });
    for (const bend of note.bend) {
      const value = Math.max(0, Math.min(16383, Math.round(8192 + (bend.cents / 200) * 8192)));
      events.push({ tick: secToTick(bend.t), data: [0xe0, value & 0x7f, (value >> 7) & 0x7f] });
    }
    events.push({ tick: Math.max(secToTick(note.start) + 1, secToTick(note.end)), data: [0x80, pitch, 0] });
  }
  const endTick = events.reduce((m, e) => Math.max(m, e.tick), 0) + tpq;
  events.push({ tick: endTick, data: [0xff, 0x2f, 0x00] });
  events.sort((a, b) => a.tick - b.tick || a.data[0] - b.data[0]);
  const track: number[] = [];
  let last = 0;
  for (const event of events) {
    track.push(...vlq(event.tick - last), ...event.data);
    last = event.tick;
  }
  const header = [0x4d, 0x54, 0x68, 0x64, 0, 0, 0, 6, 0, 0, 0, 1, (tpq >> 8) & 0xff, tpq & 0xff];
  const len = track.length;
  const trackHead = [0x4d, 0x54, 0x72, 0x6b, (len >> 24) & 0xff, (len >> 16) & 0xff, (len >> 8) & 0xff, len & 0xff];
  return Uint8Array.from([...header, ...trackHead, ...track]);
}

export function encodeTextGrid(spans: { symbol: string; t0: number; t1: number }[], xmax: number): string {
  const lines = [
    `File type = "ooTextFile"`,
    `Object class = "TextGrid"`,
    ``,
    `xmin = 0`,
    `xmax = ${xmax.toFixed(6)}`,
    `tiers? <exists>`,
    `size = 1`,
    `item []:`,
    `    item [1]:`,
    `        class = "IntervalTier"`,
    `        name = "phones"`,
    `        xmin = 0`,
    `        xmax = ${xmax.toFixed(6)}`,
    `        intervals: size = ${spans.length}`,
  ];
  spans.forEach((span, index) => {
    lines.push(
      `        intervals [${index + 1}]:`,
      `            xmin = ${span.t0.toFixed(6)}`,
      `            xmax = ${span.t1.toFixed(6)}`,
      `            text = "${span.symbol}"`,
    );
  });
  return lines.join("\n");
}

export interface ScoreEvent {
  symbol: string;
  ipa: string;
  t0: number;
  t1: number;
  voiced: boolean;
  midi: number | null;
  f1: number;
  f2: number;
  f3: number;
  kind: "vowel" | "liquid" | "noise" | "burst" | "breath" | "gap";
}

export const DEMO_SR = 22050;
export const DEMO_DUR = 6.2;

export function houseScore(): ScoreEvent[] {
  return [
    { symbol: "T", ipa: "t", t0: 0.18, t1: 0.26, voiced: false, midi: null, f1: 400, f2: 1800, f3: 2800, kind: "burst" },
    { symbol: "EY", ipa: "eɪ", t0: 0.26, t1: 0.62, voiced: true, midi: 60, f1: 460, f2: 1960, f3: 2680, kind: "vowel" },
    { symbol: "K", ipa: "k", t0: 0.62, t1: 0.72, voiced: false, midi: null, f1: 500, f2: 1500, f3: 2500, kind: "burst" },
    { symbol: "AH", ipa: "ʌ", t0: 0.72, t1: 0.98, voiced: true, midi: 64, f1: 680, f2: 1280, f3: 2500, kind: "vowel" },
    { symbol: "N", ipa: "n", t0: 1.16, t1: 1.28, voiced: true, midi: 64, f1: 320, f2: 1400, f3: 2600, kind: "liquid" },
    { symbol: "OW", ipa: "oʊ", t0: 1.28, t1: 1.92, voiced: true, midi: 67, f1: 470, f2: 820, f3: 2400, kind: "vowel" },
    { symbol: "T", ipa: "t", t0: 1.92, t1: 2.0, voiced: false, midi: null, f1: 400, f2: 1800, f3: 2800, kind: "burst" },
    { symbol: "BR", ipa: "br", t0: 2.12, t1: 2.42, voiced: false, midi: null, f1: 600, f2: 1600, f3: 3000, kind: "breath" },
    { symbol: "S", ipa: "s", t0: 2.62, t1: 2.86, voiced: false, midi: null, f1: 400, f2: 1800, f3: 4200, kind: "noise" },
    { symbol: "L", ipa: "l", t0: 2.86, t1: 3.0, voiced: true, midi: 69, f1: 380, f2: 1100, f3: 2700, kind: "liquid" },
    { symbol: "OW", ipa: "oʊ", t0: 3.0, t1: 3.62, voiced: true, midi: 69, f1: 460, f2: 860, f3: 2400, kind: "vowel" },
    { symbol: "L", ipa: "l", t0: 3.62, t1: 3.76, voiced: true, midi: 67, f1: 390, f2: 1080, f3: 2680, kind: "liquid" },
    { symbol: "IY", ipa: "i", t0: 3.76, t1: 4.45, voiced: true, midi: 67, f1: 300, f2: 2280, f3: 3100, kind: "vowel" },
    { symbol: "HH", ipa: "h", t0: 4.7, t1: 4.82, voiced: false, midi: null, f1: 500, f2: 1600, f3: 2600, kind: "noise" },
    { symbol: "AA", ipa: "ɑ", t0: 4.82, t1: 5.45, voiced: true, midi: 64, f1: 720, f2: 1180, f3: 2500, kind: "vowel" },
    { symbol: "R", ipa: "ɹ", t0: 5.45, t1: 5.62, voiced: true, midi: 60, f1: 420, f2: 1100, f3: 1700, kind: "liquid" },
    { symbol: "T", ipa: "t", t0: 5.62, t1: 5.7, voiced: false, midi: null, f1: 400, f2: 1700, f3: 2800, kind: "burst" },
  ];
}

export function scoreF0(event: ScoreEvent, time: number): number {
  if (!event.voiced || event.midi == null) return 0;
  const base = 440 * 2 ** ((event.midi - 69) / 12);
  const dur = Math.max(0.05, event.t1 - event.t0);
  const u = (time - event.t0) / dur;
  const scoop = u < 0.14 ? ((0.14 - u) / 0.14) * 0.85 : 0;
  const vib = dur > 0.32 && u > 0.22 ? Math.sin(2 * Math.PI * 5.15 * (time - event.t0)) * 0.32 : 0;
  return base * 2 ** ((vib - scoop) / 12);
}

export function eventAt(score: ScoreEvent[], time: number): ScoreEvent | null {
  for (const event of score) if (time >= event.t0 && time < event.t1) return event;
  return null;
}

export function truthF0(score: ScoreEvent[], duration: number, hop = 0.01): F0Frame[] {
  const frames: F0Frame[] = [];
  for (let t = hop; t < duration; t += hop) {
    const event = eventAt(score, t);
    const f0 = event ? scoreF0(event, t) : 0;
    frames.push({ time: t, f0, confidence: f0 ? 1 : 0, energy: f0 ? 0.2 : 0 });
  }
  return frames;
}

class Resonator {
  z1 = 0;
  z2 = 0;
  b0 = 0.05;
  a1 = 0;
  a2 = 0;
  set(freq: number, bw: number, sampleRate: number) {
    const f = Math.max(60, Math.min(sampleRate * 0.45, freq));
    const r = Math.exp((-Math.PI * bw) / sampleRate);
    const theta = (2 * Math.PI * f) / sampleRate;
    this.a1 = 2 * r * Math.cos(theta);
    this.a2 = -(r * r);
    this.b0 = (1 - r) * (1 - r);
  }
  process(x: number): number {
    const y = this.b0 * x + this.a1 * this.z1 + this.a2 * this.z2;
    this.z2 = this.z1;
    this.z1 = y;
    return y;
  }
}

export function synthesizeScore(score: ScoreEvent[], sampleRate = DEMO_SR, duration = DEMO_DUR): Float32Array {
  const n = Math.floor(sampleRate * duration);
  const y = new Float32Array(n);
  const rng = mulberry32(0x51ed);
  const r1 = new Resonator();
  const r2 = new Resonator();
  const r3 = new Resonator();
  let c1 = 500;
  let c2 = 1500;
  let c3 = 2500;
  let phase = 0;
  let prevG = 0;
  let prevNoise = 0;
  let env = 0;
  r1.set(c1, 90, sampleRate);
  r2.set(c2, 110, sampleRate);
  r3.set(c3, 160, sampleRate);
  for (let i = 0; i < n; i++) {
    const t = i / sampleRate;
    const event = eventAt(score, t);
    const target = !event || event.kind === "gap" ? 0 : event.kind === "breath" ? 0.22 : event.kind === "burst" ? 0.55 : 0.9;
    env += (target - env) * (target > env ? 0.08 : 0.02);
    let source = 0;
    if (event && (event.kind === "noise" || event.kind === "breath" || event.kind === "burst")) {
      const noise = rng() * 2 - 1;
      const hp = noise - prevNoise;
      prevNoise = noise;
      const burstEnv = event.kind === "burst" ? Math.exp(-(t - event.t0) / 0.018) : 1;
      source = hp * env * burstEnv * (event.kind === "breath" ? 0.45 : 0.8);
    }
    if (event?.voiced) {
      phase += scoreF0(event, t) / sampleRate;
      if (phase >= 1) phase -= 1;
      const open = 0.42;
      const g =
        phase < open
          ? 0.5 * (1 - Math.cos((Math.PI * phase) / open))
          : 0.5 * (1 + Math.cos((Math.PI * (phase - open)) / (1 - open)));
      source += (g - prevG) * env * 3.2;
      prevG = g;
    } else {
      prevG *= 0.8;
      phase = 0;
    }
    if (event && (i & 31) === 0) {
      c1 += (event.f1 - c1) * 0.65;
      c2 += (event.f2 - c2) * 0.65;
      c3 += (event.f3 - c3) * 0.65;
      r1.set(c1, event.kind === "liquid" ? 70 : 95, sampleRate);
      r2.set(c2, 120, sampleRate);
      r3.set(c3, 170, sampleRate);
    }
    y[i] = event?.voiced ? r1.process(source) * 0.9 + r2.process(source) * 0.38 + r3.process(source) * 0.16 : source * 0.5;
  }
  return peakNormalize(y, 0.75);
}

export function refTimeAtProc(tp: number): number {
  return tp + 0.18 * Math.tanh((tp - DEMO_DUR * 0.46) / 0.28) - 0.02;
}

export function procTimeAtRef(tr: number): number {
  let lo = 0;
  let hi = DEMO_DUR;
  for (let k = 0; k < 28; k++) {
    const mid = (lo + hi) / 2;
    if (refTimeAtProc(mid) < tr) lo = mid;
    else hi = mid;
  }
  return (lo + hi) / 2;
}

export interface Span {
  id: string;
  symbol: string;
  ipa: string;
  t0: number;
  t1: number;
  src0: number;
  src1: number;
  voiced: boolean;
  kind: ScoreEvent["kind"] | "gap";
}

export function spansFromScore(score: ScoreEvent[], duration: number, mapTime: (t: number) => number): Span[] {
  const spans: Span[] = [];
  let cursor = 0;
  const pushGap = (t1: number) => {
    if (t1 - cursor <= 0.03) return;
    const a = mapTime(cursor);
    const b = mapTime(t1);
    spans.push({
      id: `gap-${spans.length}`,
      symbol: "·",
      ipa: "",
      t0: a,
      t1: b,
      src0: a,
      src1: b,
      voiced: false,
      kind: "gap",
    });
  };
  for (const event of score) {
    pushGap(event.t0);
    spans.push({
      id: `${event.symbol}-${spans.length}`,
      symbol: event.symbol,
      ipa: event.ipa,
      t0: mapTime(event.t0),
      t1: mapTime(event.t1),
      src0: mapTime(event.t0),
      src1: mapTime(event.t1),
      voiced: event.voiced,
      kind: event.kind,
    });
    cursor = event.t1;
  }
  pushGap(duration);
  return spans.map((span) => ({
    ...span,
    t0: Math.max(0, Math.min(duration, span.t0)),
    t1: Math.max(0, Math.min(duration, span.t1)),
    src0: Math.max(0, Math.min(duration, span.src0)),
    src1: Math.max(0, Math.min(duration, span.src1)),
  }));
}

export function sliceStretch(
  samples: Float32Array,
  sampleRate: number,
  t0: number,
  t1: number,
  outDuration: number,
  voiced: boolean,
  f0: F0Frame[],
): Float32Array {
  const a = Math.max(0, Math.min(samples.length - 2, Math.round(t0 * sampleRate)));
  const b = Math.max(a + 2, Math.min(samples.length, Math.round(t1 * sampleRate)));
  const piece = samples.subarray(a, b);
  const outLen = Math.max(8, Math.round(Math.max(0.03, outDuration) * sampleRate));
  const ratio = outLen / piece.length;
  if (!voiced || ratio < 0.55 || ratio > 1.8) return wsolaToLength(piece, outLen);
  const local = f0
    .filter((frame) => frame.time >= t0 - 0.02 && frame.time <= t1 + 0.02)
    .map((frame) => ({ ...frame, time: frame.time - t0 }));
  return psolaRender({
    input: piece,
    sampleRate,
    f0: local.length ? local : trackF0(piece, sampleRate),
    outLength: outLen,
    mapIn: (s) => (s * piece.length) / outLen,
    pitchRatioAtIn: () => 1,
  });
}

export function renderSpans(samples: Float32Array, sampleRate: number, spans: Span[], f0: F0Frame[]): Float32Array {
  const end = spans.reduce((m, span) => Math.max(m, span.t1), 0);
  const out = new Float32Array(Math.max(8, Math.ceil((end + 0.05) * sampleRate)));
  for (const span of spans) {
    const dur = Math.max(0.03, span.t1 - span.t0);
    const piece = sliceStretch(samples, sampleRate, span.src0, span.src1, dur, span.voiced, f0);
    const start = Math.round(span.t0 * sampleRate);
    const fade = Math.min(48, Math.floor(piece.length / 4));
    for (let i = 0; i < piece.length; i++) {
      const o = start + i;
      if (o < 0 || o >= out.length) continue;
      let g = 1;
      if (i < fade) g = i / fade;
      else if (i > piece.length - fade) g = (piece.length - i) / Math.max(1, fade);
      out[o] += piece[i] * g;
    }
  }
  return peakNormalize(out, 0.85);
}

export function stretchWarning(span: Span): boolean {
  const src = Math.max(1e-3, span.src1 - span.src0);
  return Math.abs((span.t1 - span.t0) / src - 1) > 0.15;
}

export interface DemoBundle {
  sampleRate: number;
  duration: number;
  reference: Float32Array;
  processed: Float32Array;
  truth: F0Frame[];
  refF0: F0Frame[];
  procF0: F0Frame[];
  refSpans: Span[];
  procSpans: Span[];
  trackerMaeCents: number;
}

export function buildDemo(): DemoBundle {
  const score = houseScore();
  const reference = synthesizeScore(score, DEMO_SR, DEMO_DUR);
  const truth = truthF0(score, DEMO_DUR);
  const pitchRatio = 2 ** (1.5 / 12);
  const processed = peakNormalize(
    psolaRender({
      input: reference,
      sampleRate: DEMO_SR,
      f0: truth,
      outLength: reference.length,
      mapIn: (out) => {
        const tr = refTimeAtProc(out / DEMO_SR);
        return Math.max(0, Math.min(reference.length - 2, tr * DEMO_SR));
      },
      pitchRatioAtIn: (inSample) => (f0At(truth, inSample / DEMO_SR) > 0 ? pitchRatio : 1),
    }),
    0.75,
  );
  const refF0 = trackF0(reference, DEMO_SR);
  const procF0 = trackF0(processed, DEMO_SR);
  let mae = 0;
  let n = 0;
  for (const frame of truth) {
    if (frame.f0 <= 0) continue;
    let best = Infinity;
    let match = 0;
    for (const other of refF0) {
      const d = Math.abs(other.time - frame.time);
      if (d < best) {
        best = d;
        match = other.f0;
      }
    }
    if (match > 0 && best < 0.02) {
      mae += Math.abs(1200 * Math.log2(match / frame.f0));
      n++;
    }
  }
  return {
    sampleRate: DEMO_SR,
    duration: DEMO_DUR,
    reference,
    processed,
    truth,
    refF0,
    procF0,
    refSpans: spansFromScore(score, DEMO_DUR, (t) => t),
    procSpans: spansFromScore(score, DEMO_DUR, procTimeAtRef),
    trackerMaeCents: n ? mae / n : 0,
  };
}
