/** Versioned phoneme inventories with articulatory features and provenance. */

export type Manner = "stop" | "fric" | "affr" | "nasal" | "approx" | "glide" | "vowel";
export type Place =
  | "bilab"
  | "labden"
  | "dental"
  | "alv"
  | "postalv"
  | "pal"
  | "velar"
  | "glottal"
  | "labvel"
  | "vow";
export type Height = "close" | "nearclose" | "closemid" | "mid" | "openmid" | "nearopen" | "open";
export type Backness = "front" | "central" | "back";

export type InventoryId = "arpabet" | "ipa" | "xsampa" | "synthv-en" | "synthv-ja" | "ace" | "vocaloid";

export interface Phoneme {
  id: string;
  voiced: 0 | 1;
  manner: Manner;
  place: Place;
  height: Height;
  back: Backness;
  round: 0 | 1;
  lateral: 0 | 1;
  /** Advisory intrinsic duration (ms), order-of-magnitude from published means. */
  durationMs: number;
  citation: string;
  spellings: Partial<Record<InventoryId, string>>;
}

const CITE_EN = "English inventory aligned to ARPAbet / X-SAMPA (Wells 1995; Ladefoged & Johnson).";
const CITE_DUR = "Duration advice uses typical isolated-phoneme ranges (Klatt 1979; Crystal & House 1988), not a copied table.";
const CITE_JA = "Japanese mora set follows the SynthV/VOCALOID 5-vowel inventory (a i u e o, moraic N, geminate).";

function p(
  id: string,
  voiced: 0 | 1,
  manner: Manner,
  place: Place,
  durationMs: number,
  spellings: Partial<Record<InventoryId, string>>,
  extra?: Partial<Pick<Phoneme, "height" | "back" | "round" | "citation" | "lateral">>,
): Phoneme {
  return {
    id,
    voiced,
    manner,
    place,
    height: extra?.height ?? "mid",
    back: extra?.back ?? "central",
    round: extra?.round ?? 0,
    lateral: extra?.lateral ?? 0,
    durationMs,
    citation: `${extra?.citation ?? CITE_EN} ${CITE_DUR}`,
    spellings,
  };
}

const V = (
  id: string,
  height: Height,
  back: Backness,
  round: 0 | 1,
  durationMs: number,
  spellings: Partial<Record<InventoryId, string>>,
) =>
  p(id, 1, "vowel", "vow", durationMs, spellings, { height, back, round });

export const PHONEMES: Phoneme[] = [
  p("p", 0, "stop", "bilab", 70, { arpabet: "P", ipa: "p", xsampa: "p", "synthv-en": "p", ace: "p", vocaloid: "p" }),
  p("b", 1, "stop", "bilab", 75, { arpabet: "B", ipa: "b", xsampa: "b", "synthv-en": "b", ace: "b", vocaloid: "b" }),
  p("t", 0, "stop", "alv", 65, { arpabet: "T", ipa: "t", xsampa: "t", "synthv-en": "t", ace: "t", vocaloid: "t" }),
  p("d", 1, "stop", "alv", 70, { arpabet: "D", ipa: "d", xsampa: "d", "synthv-en": "d", ace: "d", vocaloid: "d" }),
  p("k", 0, "stop", "velar", 80, { arpabet: "K", ipa: "k", xsampa: "k", "synthv-en": "k", ace: "k", vocaloid: "k" }),
  p("g", 1, "stop", "velar", 75, { arpabet: "G", ipa: "ɡ", xsampa: "g", "synthv-en": "g", ace: "g", vocaloid: "g" }),
  p("qmark", 0, "stop", "glottal", 60, { ipa: "ʔ", xsampa: "?" }, { citation: "Glottal stop is in IPA/X-SAMPA but absent from SynthV EN, ACE, and VOCALOID symbol sets." }),
  p("f", 0, "fric", "labden", 110, { arpabet: "F", ipa: "f", xsampa: "f", "synthv-en": "f", ace: "f", vocaloid: "f" }),
  p("v", 1, "fric", "labden", 90, { arpabet: "V", ipa: "v", xsampa: "v", "synthv-en": "v", ace: "v", vocaloid: "v" }),
  p("th", 0, "fric", "dental", 95, { arpabet: "TH", ipa: "θ", xsampa: "T", "synthv-en": "T", ace: "TH", vocaloid: "T" }),
  p("dh", 1, "fric", "dental", 80, { arpabet: "DH", ipa: "ð", xsampa: "D", "synthv-en": "D", ace: "DH", vocaloid: "D" }),
  p("s", 0, "fric", "alv", 120, { arpabet: "S", ipa: "s", xsampa: "s", "synthv-en": "s", ace: "s", vocaloid: "s" }),
  p("z", 1, "fric", "alv", 100, { arpabet: "Z", ipa: "z", xsampa: "z", "synthv-en": "z", ace: "z", vocaloid: "z" }),
  p("sh", 0, "fric", "postalv", 120, { arpabet: "SH", ipa: "ʃ", xsampa: "S", "synthv-en": "S", ace: "SH", vocaloid: "S" }),
  p("zh", 1, "fric", "postalv", 95, { arpabet: "ZH", ipa: "ʒ", xsampa: "Z", "synthv-en": "Z", ace: "ZH", vocaloid: "Z" }),
  p("hh", 0, "fric", "glottal", 80, { arpabet: "HH", ipa: "h", xsampa: "h", "synthv-en": "h", ace: "HH", vocaloid: "h" }),
  p("lh", 0, "fric", "alv", 110, { ipa: "ɬ", xsampa: "K\\" }, { lateral: 1, citation: "Voiceless lateral fricative. Not in ARPAbet, SynthV, ACE, or VOCALOID English sets." }),
  p("ch", 0, "affr", "postalv", 110, { arpabet: "CH", ipa: "tʃ", xsampa: "tS", "synthv-en": "tS", ace: "CH", vocaloid: "tS" }),
  p("jh", 1, "affr", "postalv", 100, { arpabet: "JH", ipa: "dʒ", xsampa: "dZ", "synthv-en": "dZ", ace: "JH", vocaloid: "dZ" }),
  p("m", 1, "nasal", "bilab", 80, { arpabet: "M", ipa: "m", xsampa: "m", "synthv-en": "m", ace: "m", vocaloid: "m" }),
  p("n", 1, "nasal", "alv", 75, { arpabet: "N", ipa: "n", xsampa: "n", "synthv-en": "n", ace: "n", vocaloid: "n" }),
  p("ng", 1, "nasal", "velar", 90, { arpabet: "NG", ipa: "ŋ", xsampa: "N", "synthv-en": "N", ace: "NG", vocaloid: "N" }),
  p("l", 1, "approx", "alv", 75, { arpabet: "L", ipa: "l", xsampa: "l", "synthv-en": "l", ace: "l", vocaloid: "l" }),
  p("r", 1, "approx", "alv", 80, { arpabet: "R", ipa: "ɹ", xsampa: "r\\", "synthv-en": "r\\", ace: "R", vocaloid: "r\\" }),
  p("w", 1, "glide", "labvel", 70, { arpabet: "W", ipa: "w", xsampa: "w", "synthv-en": "w", ace: "w", vocaloid: "w" }),
  p("y", 1, "glide", "pal", 65, { arpabet: "Y", ipa: "j", xsampa: "j", "synthv-en": "j", ace: "Y", vocaloid: "j" }),
  V("iy", "close", "front", 0, 140, { arpabet: "IY", ipa: "i", xsampa: "i", "synthv-en": "i", ace: "IY", vocaloid: "i", "synthv-ja": "i" }),
  V("ih", "nearclose", "front", 0, 90, { arpabet: "IH", ipa: "ɪ", xsampa: "I", "synthv-en": "I", ace: "IH", vocaloid: "I" }),
  V("ey", "closemid", "front", 0, 150, { arpabet: "EY", ipa: "eɪ", xsampa: "eI", "synthv-en": "eI", ace: "EY", vocaloid: "eI" }),
  V("eh", "openmid", "front", 0, 110, { arpabet: "EH", ipa: "ɛ", xsampa: "E", "synthv-en": "E", ace: "EH", vocaloid: "E", "synthv-ja": "e" }),
  V("ae", "nearopen", "front", 0, 150, { arpabet: "AE", ipa: "æ", xsampa: "{", "synthv-en": "{", ace: "AE", vocaloid: "{" }),
  V("aa", "open", "back", 0, 160, { arpabet: "AA", ipa: "ɑ", xsampa: "A", "synthv-en": "A", ace: "AA", vocaloid: "A", "synthv-ja": "a" }),
  V("ao", "openmid", "back", 1, 160, { arpabet: "AO", ipa: "ɔ", xsampa: "O", "synthv-en": "O", ace: "AO", vocaloid: "O" }),
  V("ow", "closemid", "back", 1, 160, { arpabet: "OW", ipa: "oʊ", xsampa: "oU", "synthv-en": "oU", ace: "OW", vocaloid: "oU", "synthv-ja": "o" }),
  V("uh", "nearclose", "back", 1, 90, { arpabet: "UH", ipa: "ʊ", xsampa: "U", "synthv-en": "U", ace: "UH", vocaloid: "U" }),
  V("uw", "close", "back", 1, 140, { arpabet: "UW", ipa: "u", xsampa: "u", "synthv-en": "u", ace: "UW", vocaloid: "u", "synthv-ja": "u" }),
  V("ah", "openmid", "central", 0, 100, { arpabet: "AH", ipa: "ʌ", xsampa: "V", "synthv-en": "V", ace: "AH", vocaloid: "V" }),
  V("ax", "mid", "central", 0, 70, { arpabet: "AX", ipa: "ə", xsampa: "@", "synthv-en": "@", ace: "AX", vocaloid: "@" }),
  V("er", "mid", "central", 0, 140, { arpabet: "ER", ipa: "ɝ", xsampa: "3", "synthv-en": "3", ace: "ER", vocaloid: "3" }),
  p("N", 1, "nasal", "alv", 120, { "synthv-ja": "N", vocaloid: "N\\" }, { citation: CITE_JA }),
  p("q", 0, "stop", "glottal", 90, { "synthv-ja": "cl", vocaloid: "cl" }, { citation: `${CITE_JA} Geminate/closure is advisory only.` }),
];

export const INVENTORIES: { id: InventoryId; label: string; note: string }[] = [
  { id: "arpabet", label: "ARPAbet", note: "CMU-style English" },
  { id: "ipa", label: "IPA", note: "Includes symbols engines lack" },
  { id: "xsampa", label: "X-SAMPA", note: "ASCII IPA" },
  { id: "synthv-en", label: "SynthV EN", note: "X-SAMPA-like English set" },
  { id: "synthv-ja", label: "SynthV JA", note: "5 vowels + moraic N" },
  { id: "ace", label: "ACE Studio", note: "English ARPAbet-like" },
  { id: "vocaloid", label: "VOCALOID", note: "X-SAMPA plus JA closures" },
];

const MANNER_ORDER: Manner[] = ["stop", "fric", "affr", "nasal", "approx", "glide", "vowel"];
const PLACE_ORDER: Place[] = ["bilab", "labden", "dental", "alv", "postalv", "pal", "velar", "glottal", "labvel", "vow"];
const HEIGHT_ORDER: Height[] = ["close", "nearclose", "closemid", "mid", "openmid", "nearopen", "open"];
const BACK_ORDER: Backness[] = ["front", "central", "back"];

export function featureDistance(a: Phoneme, b: Phoneme): number {
  let d = a.voiced === b.voiced ? 0 : 1.15;
  d += Math.abs(MANNER_ORDER.indexOf(a.manner) - MANNER_ORDER.indexOf(b.manner)) * 0.8;
  d += Math.abs(PLACE_ORDER.indexOf(a.place) - PLACE_ORDER.indexOf(b.place)) * 0.45;
  if (a.lateral !== b.lateral) d += 1.6;
  if (a.manner === "vowel" && b.manner === "vowel") {
    d += Math.abs(HEIGHT_ORDER.indexOf(a.height) - HEIGHT_ORDER.indexOf(b.height)) * 0.4;
    d += Math.abs(BACK_ORDER.indexOf(a.back) - BACK_ORDER.indexOf(b.back)) * 0.4;
    if (a.round !== b.round) d += 0.35;
  } else if (a.manner === "vowel" || b.manner === "vowel") {
    d += 2.4;
  }
  return d;
}

export interface MapItem {
  source: string;
  target: string;
  canonical: string;
  status: "exact" | "substituted" | "unmappable" | "unknown";
  confidence: number;
  durationDeltaMs: number;
  citation: string;
  distance: number;
}

const UNMAPPABLE_DISTANCE = 1.35;

export function lookupSpelling(inventory: InventoryId, token: string): Phoneme | null {
  const key = token.trim();
  if (!key) return null;
  return PHONEMES.find((ph) => ph.spellings[inventory] === key) ?? null;
}

export function mapSequence(sourceInv: InventoryId, targetInv: InventoryId, text: string): MapItem[] {
  const tokens = text
    .trim()
    .split(/[\s,/;]+/)
    .filter(Boolean);
  return tokens.map((token) => {
    const src = lookupSpelling(sourceInv, token);
    if (!src) {
      return {
        source: token,
        target: "—",
        canonical: "",
        status: "unknown" as const,
        confidence: 0,
        durationDeltaMs: 0,
        citation: `“${token}” is not in the ${sourceInv} inventory shipped with this bench.`,
        distance: 99,
      };
    }
    const targetSymbol = src.spellings[targetInv];
    if (targetSymbol) {
      return {
        source: token,
        target: targetSymbol,
        canonical: src.id,
        status: "exact" as const,
        confidence: 1,
        durationDeltaMs: 0,
        citation: src.citation,
        distance: 0,
      };
    }
    let best: Phoneme | null = null;
    let bestD = Infinity;
    for (const candidate of PHONEMES) {
      if (!candidate.spellings[targetInv]) continue;
      const dist = featureDistance(src, candidate);
      if (dist < bestD) {
        bestD = dist;
        best = candidate;
      }
    }
    if (!best) {
      return {
        source: token,
        target: "—",
        canonical: src.id,
        status: "unmappable" as const,
        confidence: 0,
        durationDeltaMs: 0,
        citation: src.citation,
        distance: 99,
      };
    }
    const confidence = Math.max(0, Math.min(0.92, 1 - bestD / 3.4));
    const unmappable = bestD > UNMAPPABLE_DISTANCE;
    return {
      source: token,
      target: best.spellings[targetInv] ?? "—",
      canonical: src.id,
      status: unmappable ? ("unmappable" as const) : ("substituted" as const),
      confidence: unmappable ? Math.min(confidence, 0.35) : confidence,
      durationDeltaMs: best.durationMs - src.durationMs,
      citation: `${src.citation} Nearest ${targetInv} symbol by place/manner/voicing distance ${bestD.toFixed(2)}.`,
      distance: bestD,
    };
  });
}

export function inventorySymbols(id: InventoryId): string[] {
  return PHONEMES.map((ph) => ph.spellings[id]).filter((s): s is string => Boolean(s));
}
