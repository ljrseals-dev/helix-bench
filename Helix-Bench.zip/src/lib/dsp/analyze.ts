/** YIN, mel features, Sakoe-Chiba DTW, and alignment metrics. */

import { fft, lowpassCascade, resampleLinear, rmsRange, shiftSamples } from "./signal.ts";

export const HOP_SEC = 0.01;

export interface F0Frame {
  time: number;
  f0: number;
  confidence: number;
  energy: number;
}

export interface WarpPoint {
  i: number;
  j: number;
}

export interface WarpNode {
  ref: number;
  src: number;
}

export function f0At(frames: F0Frame[], time: number): number {
  if (frames.length === 0) return 0;
  let lo = 0;
  let hi = frames.length - 1;
  while (lo < hi) {
    const mid = (lo + hi) >> 1;
    if (frames[mid].time < time) lo = mid + 1;
    else hi = mid;
  }
  const b = frames[lo];
  const a = frames[Math.max(0, lo - 1)];
  return Math.abs(a.time - time) <= Math.abs(b.time - time) ? a.f0 : b.f0;
}

export function trackF0(
  samples: Float32Array,
  sampleRate: number,
  opts?: { fmin?: number; fmax?: number; threshold?: number; hopSec?: number },
): F0Frame[] {
  const fmin = opts?.fmin ?? 70;
  const fmax = opts?.fmax ?? 780;
  const threshold = opts?.threshold ?? 0.12;
  const hopSec = opts?.hopSec ?? HOP_SEC;
  const analysisSr = 8000;
  const filtered = lowpassCascade(samples, sampleRate, 3400, 3);
  const down = resampleLinear(filtered, sampleRate, analysisSr);
  const maxTau = Math.min(Math.round(analysisSr / fmin), Math.floor(down.length / 3));
  const minTau = Math.max(2, Math.round(analysisSr / fmax));
  const W = maxTau;
  const hop = Math.max(1, Math.round(analysisSr * hopSec));
  const frames: F0Frame[] = [];
  if (maxTau < 8 || down.length < W + maxTau + 4) return frames;

  for (let start = 0; start + W + maxTau < down.length; start += hop) {
    const diff = new Float64Array(maxTau + 1);
    for (let tau = 1; tau <= maxTau; tau++) {
      let sum = 0;
      for (let j = 0; j < W; j += 2) {
        const delta = down[start + j] - down[start + j + tau];
        sum += delta * delta;
      }
      diff[tau] = sum;
    }
    const cmnd = new Float64Array(maxTau + 1);
    cmnd[0] = 1;
    let running = 0;
    for (let tau = 1; tau <= maxTau; tau++) {
      running += diff[tau];
      cmnd[tau] = (diff[tau] * tau) / (running || 1e-12);
    }
    let bestTau = -1;
    for (let tau = minTau; tau <= maxTau; tau++) {
      if (cmnd[tau] < threshold) {
        while (tau + 1 <= maxTau && cmnd[tau + 1] < cmnd[tau]) tau++;
        bestTau = tau;
        break;
      }
    }
    const eHop = Math.max(1, Math.round(sampleRate * hopSec));
    const eStart = Math.min(samples.length - 1, Math.round((start / analysisSr) * sampleRate));
    const energy = rmsRange(samples, eStart, eHop * 2);
    let f0 = 0;
    let confidence = 0;
    if (bestTau > 1) {
      const y0 = cmnd[bestTau - 1];
      const y1 = cmnd[bestTau];
      const y2 = cmnd[Math.min(maxTau, bestTau + 1)];
      const denom = y0 + y2 - 2 * y1;
      const shift = Math.abs(denom) > 1e-12 ? (y0 - y2) / (2 * denom) : 0;
      const tau = bestTau + Math.max(-0.5, Math.min(0.5, shift));
      f0 = analysisSr / tau;
      confidence = Math.max(0, Math.min(1, 1 - y1));
    }
    frames.push({ time: (start + W * 0.5) / analysisSr, f0, confidence, energy });
  }

  let peakE = 1e-8;
  for (const frame of frames) peakE = Math.max(peakE, frame.energy);
  for (const frame of frames) {
    if (frame.energy < peakE * 0.07) {
      frame.f0 = 0;
      frame.confidence = 0;
    }
  }
  return medianSmoothF0(frames, 5);
}

function medianSmoothF0(frames: F0Frame[], win: number): F0Frame[] {
  const out = frames.map((frame) => ({ ...frame }));
  const half = Math.floor(win / 2);
  for (let i = 0; i < out.length; i++) {
    if (out[i].f0 <= 0) continue;
    const vals: number[] = [];
    for (let k = i - half; k <= i + half; k++) {
      if (k >= 0 && k < frames.length && frames[k].f0 > 0) vals.push(frames[k].f0);
    }
    if (vals.length < 3) continue;
    vals.sort((a, b) => a - b);
    const med = vals[vals.length >> 1];
    const cents = 1200 * Math.log2(out[i].f0 / med);
    if (Math.abs(cents) > 650) {
      out[i].f0 = med;
      out[i].confidence *= 0.6;
    }
  }
  return out;
}

function hzToMel(hz: number): number {
  return 2595 * Math.log10(1 + hz / 700);
}
function melToHz(mel: number): number {
  return 700 * (10 ** (mel / 2595) - 1);
}

const melCache = new Map<string, Float64Array[]>();

function melFilters(sampleRate: number, nfft: number, nMels: number): Float64Array[] {
  const key = `${sampleRate}:${nfft}:${nMels}`;
  const cached = melCache.get(key);
  if (cached) return cached;
  const mMin = hzToMel(70);
  const mMax = hzToMel(Math.min(7600, sampleRate / 2 - 80));
  const edges = new Float64Array(nMels + 2);
  for (let i = 0; i < edges.length; i++) {
    const hz = melToHz(mMin + ((mMax - mMin) * i) / (edges.length - 1));
    edges[i] = Math.floor(((nfft + 1) * hz) / sampleRate);
  }
  const filters: Float64Array[] = [];
  for (let m = 1; m <= nMels; m++) {
    const filt = new Float64Array(nfft / 2);
    const left = edges[m - 1];
    const center = edges[m];
    const right = edges[m + 1];
    for (let k = left; k < center; k++) {
      if (k >= 0 && k < filt.length && center !== left) filt[k] = (k - left) / (center - left);
    }
    for (let k = center; k < right; k++) {
      if (k >= 0 && k < filt.length && right !== center) filt[k] = (right - k) / (right - center);
    }
    filters.push(filt);
  }
  melCache.set(key, filters);
  return filters;
}

export interface MelFrame {
  time: number;
  bands: Float64Array;
  energy: number;
}

export function melFrames(samples: Float32Array, sampleRate: number, nMels = 12, hopSec = HOP_SEC): MelFrame[] {
  const nfft = 512;
  const hop = Math.max(1, Math.round(sampleRate * hopSec));
  const filters = melFilters(sampleRate, nfft, nMels);
  const out: MelFrame[] = [];
  const re = new Float64Array(nfft);
  const im = new Float64Array(nfft);
  for (let start = 0; start + nfft <= samples.length; start += hop) {
    re.fill(0);
    im.fill(0);
    let energy = 0;
    for (let i = 0; i < nfft; i++) {
      const w = 0.5 - 0.5 * Math.cos((2 * Math.PI * i) / (nfft - 1));
      const s = samples[start + i];
      energy += s * s;
      re[i] = s * w;
    }
    fft(re, im, false);
    const mags = new Float64Array(nfft / 2);
    for (let k = 0; k < mags.length; k++) mags[k] = Math.hypot(re[k], im[k]);
    const bands = new Float64Array(nMels);
    let mean = 0;
    for (let b = 0; b < nMels; b++) {
      let acc = 0;
      const filt = filters[b];
      for (let k = 0; k < mags.length; k++) acc += mags[k] * filt[k];
      bands[b] = Math.log(acc + 1e-8);
      mean += bands[b];
    }
    mean /= nMels;
    for (let b = 0; b < nMels; b++) bands[b] -= mean;
    out.push({ time: (start + nfft / 2) / sampleRate, bands, energy: Math.sqrt(energy / nfft) });
  }
  return out;
}

export function featuresOf(samples: Float32Array, sampleRate: number): Float64Array[] {
  return melFrames(samples, sampleRate, 12, HOP_SEC).map((frame) => {
    const feat = new Float64Array(13);
    feat.set(frame.bands);
    feat[12] = Math.log(frame.energy + 1e-8);
    return feat;
  });
}

function vecDist(a: Float64Array, b: Float64Array): number {
  let s = 0;
  const n = Math.min(a.length, b.length);
  for (let i = 0; i < n; i++) {
    const d = a[i] - b[i];
    s += d * d;
  }
  return Math.sqrt(s);
}

export function dtw(a: Float64Array[], b: Float64Array[], radius = 40): { path: WarpPoint[]; meanCost: number } {
  const n = a.length;
  const m = b.length;
  if (!n || !m) return { path: [], meanCost: 0 };
  const INF = 1e15;
  const cost = new Float64Array(n * m);
  cost.fill(INF);
  const pred = new Uint8Array(n * m);
  const at = (i: number, j: number) => i * m + j;
  for (let i = 0; i < n; i++) {
    const center = Math.round((i * (m - 1)) / Math.max(1, n - 1));
    let j0 = Math.max(0, center - radius);
    let j1 = Math.min(m - 1, center + radius);
    if (i === 0) j0 = 0;
    if (i === n - 1) j1 = m - 1;
    for (let j = j0; j <= j1; j++) {
      const local = vecDist(a[i], b[j]);
      if (i === 0 && j === 0) {
        cost[0] = local;
        continue;
      }
      let best = INF;
      let how = 0;
      if (i > 0 && j > 0 && cost[at(i - 1, j - 1)] < best) {
        best = cost[at(i - 1, j - 1)];
        how = 0;
      }
      if (i > 1 && j > 0 && cost[at(i - 2, j - 1)] < best) {
        best = cost[at(i - 2, j - 1)];
        how = 1;
      }
      if (i > 0 && j > 1 && cost[at(i - 1, j - 2)] < best) {
        best = cost[at(i - 1, j - 2)];
        how = 2;
      }
      if (i > 0 && cost[at(i - 1, j)] < best) {
        best = cost[at(i - 1, j)];
        how = 3;
      }
      if (j > 0 && cost[at(i, j - 1)] < best) {
        best = cost[at(i, j - 1)];
        how = 4;
      }
      if (best >= INF / 2) continue;
      cost[at(i, j)] = best + local * (how === 1 || how === 2 ? 1.12 : 1);
      pred[at(i, j)] = how;
    }
  }
  let i = n - 1;
  let j = m - 1;
  if (cost[at(i, j)] >= INF / 2) {
    let best = INF;
    for (let jj = 0; jj < m; jj++) {
      if (cost[at(i, jj)] < best) {
        best = cost[at(i, jj)];
        j = jj;
      }
    }
  }
  const path: WarpPoint[] = [];
  let guard = 0;
  while ((i > 0 || j > 0) && guard++ < n + m + 8) {
    path.push({ i, j });
    const how = pred[at(i, j)];
    if (how === 0 && i > 0 && j > 0) {
      i--;
      j--;
    } else if (how === 1 && i > 1 && j > 0) {
      i -= 2;
      j--;
    } else if (how === 2 && i > 0 && j > 1) {
      i--;
      j -= 2;
    } else if (how === 3 && i > 0) i--;
    else if (how === 4 && j > 0) j--;
    else if (i > 0 && j > 0) {
      i--;
      j--;
    } else if (i > 0) i--;
    else j--;
  }
  path.push({ i: 0, j: 0 });
  path.reverse();
  const end = path[path.length - 1];
  const total = cost[at(end.i, end.j)];
  return { path, meanCost: Number.isFinite(total) ? total / path.length : 0 };
}

export function dtwCausal(
  a: Float64Array[],
  b: Float64Array[],
  radius: number,
  lookahead: number,
): { path: WarpPoint[]; microsPerFrame: number } {
  const n = a.length;
  const m = b.length;
  const INF = 1e15;
  const cost = new Float64Array(n * m);
  cost.fill(INF);
  const pred = new Uint8Array(n * m);
  const at = (i: number, j: number) => i * m + j;
  const t0 = typeof performance !== "undefined" ? performance.now() : Date.now();
  for (let i = 0; i < n; i++) {
    const center = Math.round((i * (m - 1)) / Math.max(1, n - 1));
    const j0 = i === 0 ? 0 : Math.max(0, center - radius);
    const j1 = Math.min(m - 1, center + radius, i + Math.max(0, lookahead));
    for (let j = j0; j <= j1; j++) {
      const local = vecDist(a[i], b[j]);
      if (i === 0 && j === 0) {
        cost[0] = local;
        continue;
      }
      let best = INF;
      let how = 0;
      if (i > 0 && j > 0 && cost[at(i - 1, j - 1)] < best) {
        best = cost[at(i - 1, j - 1)];
        how = 0;
      }
      if (i > 1 && j > 0 && cost[at(i - 2, j - 1)] < best) {
        best = cost[at(i - 2, j - 1)];
        how = 1;
      }
      if (i > 0 && j > 1 && cost[at(i - 1, j - 2)] < best) {
        best = cost[at(i - 1, j - 2)];
        how = 2;
      }
      if (best >= INF / 2) continue;
      cost[at(i, j)] = best + local;
      pred[at(i, j)] = how;
    }
  }
  const elapsed = (typeof performance !== "undefined" ? performance.now() : Date.now()) - t0;
  let i = n - 1;
  let j = 0;
  let best = INF;
  for (let jj = 0; jj < m; jj++) {
    if (cost[at(i, jj)] < best) {
      best = cost[at(i, jj)];
      j = jj;
    }
  }
  const path: WarpPoint[] = [];
  let guard = 0;
  while ((i > 0 || j > 0) && guard++ < n + m + 8) {
    path.push({ i, j });
    const how = pred[at(i, j)];
    if (how === 0 && i > 0 && j > 0) {
      i--;
      j--;
    } else if (how === 1 && i > 1) {
      i -= 2;
      j = Math.max(0, j - 1);
    } else if (how === 2 && j > 1) {
      i = Math.max(0, i - 1);
      j -= 2;
    } else if (i > 0) i--;
    else if (j > 0) j--;
    else break;
  }
  path.push({ i: 0, j: 0 });
  path.reverse();
  return { path, microsPerFrame: (elapsed * 1000) / Math.max(1, n) };
}

export function pathErrorMs(causal: WarpPoint[], offline: WarpPoint[], hopSec = HOP_SEC): number {
  const offlineAt = new Map<number, number>();
  for (const point of offline) offlineAt.set(point.i, point.j);
  let acc = 0;
  let n = 0;
  let lastJ = 0;
  for (const point of causal) {
    const oj = offlineAt.get(point.i);
    if (oj !== undefined) lastJ = oj;
    acc += Math.abs(point.j - (oj ?? lastJ)) * hopSec * 1000;
    n++;
  }
  return n ? acc / n : 0;
}

function rdp(points: WarpNode[], epsilon: number): WarpNode[] {
  if (points.length < 3) return points.slice();
  const a = points[0];
  const b = points[points.length - 1];
  const dx = b.ref - a.ref || 1e-6;
  const dy = b.src - a.src;
  let maxD = 0;
  let index = 0;
  for (let i = 1; i < points.length - 1; i++) {
    const proj = a.src + dy * ((points[i].ref - a.ref) / dx);
    const d = Math.abs(points[i].src - proj);
    if (d > maxD) {
      maxD = d;
      index = i;
    }
  }
  if (maxD <= epsilon) return [a, b];
  const left = rdp(points.slice(0, index + 1), epsilon);
  const right = rdp(points.slice(index), epsilon);
  return left.slice(0, -1).concat(right);
}

export function nodesFromPath(path: WarpPoint[], hopSec = HOP_SEC, epsilon = 0.025): WarpNode[] {
  if (!path.length) return [];
  const dense: WarpNode[] = [];
  const step = Math.max(1, Math.floor(path.length / 240));
  for (let k = 0; k < path.length; k += step) dense.push({ ref: path[k].j * hopSec, src: path[k].i * hopSec });
  const last = path[path.length - 1];
  dense.push({ ref: last.j * hopSec, src: last.i * hopSec });
  const simplified = rdp(dense, epsilon);
  for (let i = 1; i < simplified.length; i++) {
    if (simplified[i].ref < simplified[i - 1].ref) simplified[i].ref = simplified[i - 1].ref;
    if (simplified[i].src < simplified[i - 1].src) simplified[i].src = simplified[i - 1].src;
  }
  return simplified;
}

export function mapFromNodes(nodes: WarpNode[]): (refT: number) => number {
  if (!nodes.length) return (t) => t;
  return (refT: number) => {
    if (refT <= nodes[0].ref) return nodes[0].src + (refT - nodes[0].ref);
    const last = nodes[nodes.length - 1];
    if (refT >= last.ref) {
      const prev = nodes[Math.max(0, nodes.length - 2)];
      const slope = (last.src - prev.src) / Math.max(1e-4, last.ref - prev.ref);
      return last.src + (refT - last.ref) * slope;
    }
    let lo = 0;
    let hi = nodes.length - 1;
    while (hi - lo > 1) {
      const mid = (lo + hi) >> 1;
      if (nodes[mid].ref <= refT) lo = mid;
      else hi = mid;
    }
    const a = nodes[lo];
    const b = nodes[hi];
    const u = (refT - a.ref) / Math.max(1e-6, b.ref - a.ref);
    return a.src + (b.src - a.src) * u;
  };
}

export function spectralFluxTimes(samples: Float32Array, sampleRate: number): number[] {
  const frames = melFrames(samples, sampleRate, 12, HOP_SEC);
  const flux: number[] = [];
  for (let i = 1; i < frames.length; i++) {
    let s = 0;
    for (let k = 0; k < frames[i].bands.length; k++) {
      const d = frames[i].bands[k] - frames[i - 1].bands[k];
      if (d > 0) s += d;
    }
    flux.push(s);
  }
  let mean = 0;
  for (const v of flux) mean += v;
  mean /= Math.max(1, flux.length);
  let variance = 0;
  for (const v of flux) variance += (v - mean) ** 2;
  const std = Math.sqrt(variance / Math.max(1, flux.length));
  const times: number[] = [];
  for (let i = 1; i < flux.length - 1; i++) {
    if (flux[i] > mean + std * 1.4 && flux[i] >= flux[i - 1] && flux[i] >= flux[i + 1]) times.push(frames[i + 1].time);
  }
  return times;
}

export function protectTransients(nodes: WarpNode[], peakSrcTimes: number[]): WarpNode[] {
  if (nodes.length < 2 || !peakSrcTimes.length) return nodes.map((node) => ({ ...node }));
  const out = nodes.map((node) => ({ ...node }));
  for (const peak of peakSrcTimes) {
    let nearest = 0;
    let best = Infinity;
    for (let i = 0; i < out.length; i++) {
      const d = Math.abs(out[i].src - peak);
      if (d < best) {
        best = d;
        nearest = i;
      }
    }
    if (best > 0.08 || nearest === 0 || nearest === out.length - 1) continue;
    const prev = out[nearest - 1];
    const node = out[nearest];
    node.src = node.src * 0.45 + (prev.src + (node.ref - prev.ref)) * 0.55;
  }
  for (let i = 1; i < out.length; i++) {
    if (out[i].src < out[i - 1].src) out[i].src = out[i - 1].src + 0.001;
    if (out[i].ref < out[i - 1].ref) out[i].ref = out[i - 1].ref + 0.001;
  }
  return out;
}

function cepstralEnvDb(frame: Float32Array, nfft: number, lifter = 24): Float64Array {
  const re = new Float64Array(nfft);
  const im = new Float64Array(nfft);
  for (let i = 0; i < frame.length && i < nfft; i++) {
    const w = 0.5 - 0.5 * Math.cos((2 * Math.PI * i) / Math.max(1, Math.min(frame.length, nfft) - 1));
    re[i] = frame[i] * w;
  }
  fft(re, im, false);
  const logMag = new Float64Array(nfft);
  for (let k = 0; k <= nfft / 2; k++) {
    const v = Math.log(Math.hypot(re[k], im[k]) + 1e-10);
    logMag[k] = v;
    if (k > 0 && k < nfft / 2) logMag[nfft - k] = v;
  }
  const cre = logMag;
  const cim = new Float64Array(nfft);
  fft(cre, cim, true);
  for (let i = lifter; i <= nfft - lifter; i++) {
    cre[i] = 0;
    cim[i] = 0;
  }
  fft(cre, cim, false);
  const env = new Float64Array(nfft / 2);
  for (let k = 0; k < env.length; k++) env[k] = (20 / Math.LN10) * cre[k];
  return env;
}

export function envelopeErrorDb(a: Float32Array, b: Float32Array, sampleRate: number): number {
  const nfft = 1024;
  const hop = 256;
  const frames = Math.min(Math.floor((a.length - nfft) / hop), Math.floor((b.length - nfft) / hop));
  const k0 = Math.max(1, Math.floor((250 * nfft) / sampleRate));
  const k1 = Math.min(nfft / 2 - 1, Math.floor((4200 * nfft) / sampleRate));
  let acc = 0;
  let n = 0;
  for (let i = 0; i < frames; i += 2) {
    const start = i * hop;
    if (rmsRange(a, start, nfft) < 0.02 || rmsRange(b, start, nfft) < 0.02) continue;
    const ea = cepstralEnvDb(a.subarray(start, start + nfft), nfft);
    const eb = cepstralEnvDb(b.subarray(start, start + nfft), nfft);
    let ma = 0;
    let mb = 0;
    const count = k1 - k0 + 1;
    for (let k = k0; k <= k1; k++) {
      ma += ea[k];
      mb += eb[k];
    }
    ma /= count;
    mb /= count;
    for (let k = k0; k <= k1; k++) {
      acc += Math.abs(ea[k] - ma - (eb[k] - mb));
      n++;
    }
  }
  return n ? acc / n : 0;
}

export function envelopeCurves(samples: Float32Array, sampleRate: number): { hz: number; db: number }[] {
  const nfft = 1024;
  const start = Math.max(0, Math.floor(samples.length / 2 - nfft / 2));
  const frame = new Float32Array(nfft);
  frame.set(samples.subarray(start, Math.min(samples.length, start + nfft)));
  const env = cepstralEnvDb(frame, nfft);
  const pts: { hz: number; db: number }[] = [];
  for (let k = 2; k < env.length; k += 2) pts.push({ hz: (k * sampleRate) / nfft, db: env[k] });
  return pts;
}

function dctOrtho(bands: Float64Array): Float64Array {
  const n = bands.length;
  const c = new Float64Array(n);
  const scale = Math.sqrt(2 / n);
  for (let k = 0; k < n; k++) {
    let s = 0;
    for (let i = 0; i < n; i++) s += bands[i] * Math.cos((Math.PI * k * (i + 0.5)) / n);
    c[k] = scale * s * (k === 0 ? 1 / Math.SQRT2 : 1);
  }
  return c;
}

export function melCepstralDistortion(a: Float32Array, b: Float32Array, sampleRate: number): number {
  const fa = melFrames(a, sampleRate, 20, 0.012);
  const fb = melFrames(b, sampleRate, 20, 0.012);
  const n = Math.min(fa.length, fb.length);
  let acc = 0;
  let count = 0;
  for (let i = 0; i < n; i++) {
    if (fa[i].energy < 0.015 || fb[i].energy < 0.015) continue;
    const ca = dctOrtho(fa[i].bands);
    const cb = dctOrtho(fb[i].bands);
    let s = 0;
    for (let k = 1; k <= 12 && k < ca.length; k++) {
      const d = ca[k] - cb[k];
      s += d * d;
    }
    acc += (10 / Math.LN10) * Math.sqrt(2 * s);
    count++;
  }
  return count ? acc / count : 0;
}

function envelope(samples: Float32Array, sampleRate: number): Float64Array {
  const hop = Math.max(1, Math.round(sampleRate * HOP_SEC));
  const win = hop * 2;
  const frames = Math.max(0, Math.floor((samples.length - win) / hop));
  const env = new Float64Array(frames);
  for (let i = 0; i < frames; i++) env[i] = rmsRange(samples, i * hop, win);
  return env;
}

export function timingOffsetMs(reference: Float32Array, processed: Float32Array, sampleRate: number): number {
  const a = envelope(reference, sampleRate);
  const b = envelope(processed, sampleRate);
  const maxLag = Math.min(40, Math.floor(a.length / 3));
  let best = -Infinity;
  let bestLag = 0;
  for (let lag = -maxLag; lag <= maxLag; lag++) {
    let s = 0;
    let n = 0;
    for (let i = 0; i < a.length; i++) {
      const j = i + lag;
      if (j < 0 || j >= b.length) continue;
      s += a[i] * b[j];
      n++;
    }
    if (n > 8 && s > best) {
      best = s;
      bestLag = lag;
    }
  }
  return bestLag * HOP_SEC * 1000;
}

export interface QcWeights {
  f0: number;
  time: number;
  mcd: number;
  boundary: number;
}

export interface QcReport {
  f0MaeCents: number;
  f0Corr: number;
  voicedFrames: number;
  offsetMs: number;
  mcd: number;
  boundaryMs: number;
  score: number;
  series: { t: number; cents: number }[];
  flags: { t0: number; t1: number; reason: string }[];
}

function pearson(xs: number[], ys: number[]): number {
  const n = Math.min(xs.length, ys.length);
  if (n < 3) return 0;
  let mx = 0;
  let my = 0;
  for (let i = 0; i < n; i++) {
    mx += xs[i];
    my += ys[i];
  }
  mx /= n;
  my /= n;
  let num = 0;
  let dx = 0;
  let dy = 0;
  for (let i = 0; i < n; i++) {
    const a = xs[i] - mx;
    const b = ys[i] - my;
    num += a * b;
    dx += a * a;
    dy += b * b;
  }
  return dx > 0 && dy > 0 ? num / Math.sqrt(dx * dy) : 0;
}

export function analyzeAlignment(opts: {
  reference: Float32Array;
  processed: Float32Array;
  sampleRate: number;
  refF0?: F0Frame[];
  procF0?: F0Frame[];
  refOnsets?: number[];
  procOnsets?: number[];
  weights: QcWeights;
}): QcReport {
  const refF0 = opts.refF0 ?? trackF0(opts.reference, opts.sampleRate);
  const procF0 = opts.procF0 ?? trackF0(opts.processed, opts.sampleRate);
  const xs: number[] = [];
  const ys: number[] = [];
  const series: { t: number; cents: number }[] = [];
  for (const frame of refF0) {
    if (frame.f0 <= 0) continue;
    let nearest = procF0[0];
    let best = Infinity;
    for (const other of procF0) {
      const d = Math.abs(other.time - frame.time);
      if (d < best) {
        best = d;
        nearest = other;
      }
    }
    if (!nearest || nearest.f0 <= 0 || best > 0.02) continue;
    xs.push(frame.f0);
    ys.push(nearest.f0);
    series.push({ t: frame.time, cents: 1200 * Math.log2(nearest.f0 / frame.f0) });
  }
  const f0MaeCents = series.length ? series.reduce((s, p) => s + Math.abs(p.cents), 0) / series.length : 0;
  const offsetMs = timingOffsetMs(opts.reference, opts.processed, opts.sampleRate);
  const mcd = melCepstralDistortion(opts.reference, shiftSamples(opts.processed, opts.sampleRate, offsetMs), opts.sampleRate);
  const pairs = Math.min(opts.refOnsets?.length ?? 0, opts.procOnsets?.length ?? 0);
  let boundaryMs = 0;
  if (pairs && opts.refOnsets && opts.procOnsets) {
    let s = 0;
    for (let i = 0; i < pairs; i++) s += Math.abs(opts.procOnsets[i] - opts.refOnsets[i]) * 1000;
    boundaryMs = s / pairs;
  }
  const w = opts.weights;
  const wsum = Math.max(1e-6, w.f0 + w.time + w.mcd + w.boundary);
  const score =
    (100 *
      (w.f0 * Math.exp(-f0MaeCents / 80) +
        w.time * Math.exp(-Math.abs(offsetMs) / 40) +
        w.mcd * Math.exp(-mcd / 5) +
        w.boundary * Math.exp(-boundaryMs / 35))) /
    wsum;
  const flags: QcReport["flags"] = [];
  let run = -1;
  for (let i = 0; i < series.length; i++) {
    const bad = Math.abs(series[i].cents) > 80;
    if (bad && run < 0) run = i;
    if ((!bad || i === series.length - 1) && run >= 0) {
      const end = bad && i === series.length - 1 ? i : i - 1;
      if (series[end].t - series[run].t > 0.06) {
        flags.push({ t0: series[run].t, t1: series[end].t, reason: "F0 off by more than 80 cents" });
      }
      run = -1;
    }
  }
  return { f0MaeCents, f0Corr: pearson(xs, ys), voicedFrames: series.length, offsetMs, mcd, boundaryMs, score, series, flags };
}

export function spectralFlatnessFrame(samples: Float32Array, start: number, nfft: number): number {
  if (start < 0 || start + nfft > samples.length) return 0;
  const re = new Float64Array(nfft);
  const im = new Float64Array(nfft);
  for (let i = 0; i < nfft; i++) {
    const w = 0.5 - 0.5 * Math.cos((2 * Math.PI * i) / (nfft - 1));
    re[i] = samples[start + i] * w;
  }
  fft(re, im, false);
  let logSum = 0;
  let arith = 0;
  const bins = nfft / 2 - 1;
  for (let k = 1; k <= bins; k++) {
    const mag = Math.hypot(re[k], im[k]) + 1e-12;
    logSum += Math.log(mag);
    arith += mag;
  }
  return Math.exp(logSum / bins) / (arith / bins);
}
